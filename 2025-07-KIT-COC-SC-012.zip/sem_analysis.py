
"""
=============================================================================
 The Economic Impact of Gender Inequality in Educational Access on
 Sustainable Development in Emerging Economies
 – Full Survey Data Generation + SEM Analysis –
=============================================================================
Constructs
  IV  : GBEI  – Gender-Based Educational Inequality     (GBEI1-5)
  M1  : FLFP  – Female Labour Force Participation       (FLFP1-5)
  M2  : II    – Income Inequality                       (II1-5)
  MOD : PEE   – Public Expenditure on Education         (PEE1-5)
  DV  : EG    – Economic Growth                         (EG1-5)

Hypotheses
  H1 : GBEI → EG  (negative)
  H2 : GBEI → FLFP → EG  (mediation)
  H3 : GBEI → II  → EG  (mediation)
  H4 : GBEI × PEE → EG  (moderation – higher PEE weakens negative effect)
=============================================================================
"""

import os, warnings, itertools
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.patheffects as pe
from matplotlib.patches import FancyArrowPatch
import seaborn as sns
from scipy import stats
from sklearn.preprocessing import StandardScaler
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
import pingouin as pg

warnings.filterwarnings("ignore")

# ── output directory ──────────────────────────────────────────────────────────
OUT = r"d:\Alan christo\November2026\2025-07-KIT-COC-SC-012\Analysis_Output"
os.makedirs(OUT, exist_ok=True)

EXCEL_PATH = os.path.join(OUT, "Full_Analysis_Tables.xlsx")
writer     = pd.ExcelWriter(EXCEL_PATH, engine="openpyxl")

sns.set_theme(style="whitegrid", palette="muted", font_scale=1.1)
plt.rcParams.update({"figure.dpi": 150, "savefig.bbox": "tight",
                     "font.family": "DejaVu Sans"})

SEED = 42
np.random.seed(SEED)
N    = 400          # 200 urban + 200 rural

# =============================================================================
# 1.  SYNTHETIC SURVEY DATA GENERATION (Cronbach α > 0.85)
# =============================================================================
print("=" * 70)
print(" STEP 1 – SYNTHETIC DATA GENERATION")
print("=" * 70)

def gen_likert_construct(n, mu, sigma, items=5, alpha_target=0.90):
    """
    Generate correlated Likert-scale items with guaranteed high α > 0.85.
    Strategy: draw a single latent factor, add tiny unique noise, then
    post-hoc verify and re-seed until α ≥ 0.86 for every construct.
    """
    best_data, best_alpha = None, 0.0
    for attempt in range(200):
        # latent factor (continuous, 0-1)
        factor = np.random.normal(mu, sigma, n)
        factor = np.clip(factor, 0, 1)
        # noise level: very small so items are tightly correlated
        noise_sd = 0.08
        items_raw = np.column_stack(
            [factor + np.random.normal(0, noise_sd, n) for _ in range(items)]
        )
        # rescale each item to [1,5] Likert
        for col in range(items):
            c = items_raw[:, col]
            c = (c - c.min()) / (c.max() - c.min()) * 4 + 1
            items_raw[:, col] = np.clip(np.round(c), 1, 5).astype(int)
        # compute alpha
        k = items
        item_vars  = items_raw.var(ddof=1, axis=0)
        total_var  = items_raw.sum(axis=1).var(ddof=1)
        alpha = (k / (k - 1)) * (1 - item_vars.sum() / total_var)
        if alpha > best_alpha:
            best_alpha = alpha
            best_data  = items_raw.copy()
        if alpha >= 0.86:
            break
    return best_data

# Generate latent-factor data for each construct (all will have α ≥ 0.86)
GBEI_data = gen_likert_construct(N, mu=0.68, sigma=0.20)
FLFP_data = gen_likert_construct(N, mu=0.55, sigma=0.20)
II_data   = gen_likert_construct(N, mu=0.65, sigma=0.20)
PEE_data  = gen_likert_construct(N, mu=0.50, sigma=0.20)
EG_data   = gen_likert_construct(N, mu=0.52, sigma=0.20)

# --- introduce theoretically sound inter-construct correlations ---
# Strategy: Keep raw items INTACT (preserves α) and encode structural
# paths into the COMPOSITE SCORES used in regression / SEM only.
# The raw Likert items (what go into the CSV / Excel) are untouched.

GBEI_lat = GBEI_data.mean(axis=1)   # z-score for path weighting
FLFP_lat = FLFP_data.mean(axis=1)
II_lat   = II_data.mean(axis=1)
PEE_lat  = PEE_data.mean(axis=1)
EG_lat   = EG_data.mean(axis=1)

def zs(x): return (x - x.mean()) / x.std()


# ── HIGH R² structural encoding (target R² > 0.85 for all endogenous) ──────
# Strategy: make each endogenous variable almost ENTIRELY explained by its
# predictors with only tiny residual noise, while keeping within-construct
# item correlation tight (noise_sd=0.04) so Cronbach α stays > 0.85.

# --- FLFP = f(GBEI)  target R²(FLFP|GBEI) ≈ 0.90 ---
# FLFP_latent ≈ -0.95*GBEI + tiny residual (small noise → high R²)
flfp_latent = -0.95 * zs(GBEI_lat) + np.random.normal(0, 0.10, N)
flfp_norm   = (flfp_latent - flfp_latent.min()) / (flfp_latent.max() - flfp_latent.min())
for col in range(5):
    raw = flfp_norm + np.random.normal(0, 0.02, N)   # 0.02 → keeps α high
    raw = np.clip(raw, 0, 1)
    FLFP_data[:, col] = np.clip(np.round(raw * 4 + 1).astype(int), 1, 5)

# --- II = f(GBEI)   target R²(II|GBEI) ≈ 0.90 ---
ii_latent = 0.95 * zs(GBEI_lat) + np.random.normal(0, 0.10, N)
ii_norm   = (ii_latent - ii_latent.min()) / (ii_latent.max() - ii_latent.min())
for col in range(5):
    raw = ii_norm + np.random.normal(0, 0.02, N)
    raw = np.clip(raw, 0, 1)
    II_data[:, col] = np.clip(np.round(raw * 4 + 1).astype(int), 1, 5)

# --- EG = f(GBEI, FLFP, II, PEE)  target R²(EG|all) ≈ 0.92 ---
# PEE moderates GBEI: include interaction so H4 is also significant
flfp_lat2  = FLFP_data.mean(axis=1)
ii_lat2    = II_data.mean(axis=1)
gbei_z     = zs(GBEI_lat)
flfp_z     = zs(flfp_lat2)
ii_z       = zs(ii_lat2)
pee_z      = zs(PEE_lat)
interact_z = gbei_z * pee_z          # GBEI × PEE interaction

eg_latent  = (- 0.50 * gbei_z        # H1: GBEI → EG (negative)
              + 0.40 * flfp_z         # H2b: FLFP → EG (positive)
              - 0.35 * ii_z           # H3b: II → EG (negative)
              + 0.30 * pee_z          # PEE main effect
              + 0.25 * interact_z     # H4: GBEI×PEE moderates (positive: high PEE weakens negative GBEI effect)
              + np.random.normal(0, 0.08, N))   # tiny residual

eg_norm    = (eg_latent - eg_latent.min()) / (eg_latent.max() - eg_latent.min())
for col in range(5):
    raw = eg_norm + np.random.normal(0, 0.02, N)
    raw = np.clip(raw, 0, 1)
    EG_data[:, col] = np.clip(np.round(raw * 4 + 1).astype(int), 1, 5)

# --- demographic variables ---
location = np.array(["Urban"] * 200 + ["Rural"] * 200)
gender   = np.where(np.random.uniform(size=N) < 0.52, "Female", "Male")
age_cats = ["Under 18", "18-24", "25-34", "35-44", "45 and above"]
age_probs= [0.05, 0.25, 0.30, 0.25, 0.15]
age      = np.random.choice(age_cats, N, p=age_probs)
edu_cats = ["Primary", "Middle School", "High School", "College/University", "Graduate"]
edu_probs= [0.10, 0.20, 0.30, 0.30, 0.10]
education = np.random.choice(edu_cats, N, p=edu_probs)
occ_cats = ["Student", "Employed", "Self-employed", "Unemployed", "Homemaker", "Other"]
occ_probs= [0.15, 0.35, 0.20, 0.10, 0.12, 0.08]
occupation= np.random.choice(occ_cats, N, p=occ_probs)
income_cats = ["Below CNY 3,000","CNY 3,000-6,000","CNY 6,001-10,000","Above CNY 10,000"]
income_probs= [0.25, 0.35, 0.25, 0.15]
income    = np.random.choice(income_cats, N, p=income_probs)
ethnic    = np.random.choice(["Yes","No","Prefer not to say"], N, p=[0.30,0.60,0.10])
hh_size   = np.random.choice(["1-2","3-4","5-6","More than 6"], N, p=[0.10,0.45,0.30,0.15])
internet  = np.random.choice(["Always","Sometimes","Rarely","Never"], N, p=[0.25,0.35,0.25,0.15])
dist_school= np.random.choice(["<1 km","1-5 km","5-10 km",">10 km"], N, p=[0.20,0.40,0.25,0.15])
flfp_hh   = np.random.choice(["Yes","No","Not applicable"], N, p=[0.45,0.35,0.20])

# assemble main dataframe
item_cols = (
    [f"GBEI{i}" for i in range(1,6)] +
    [f"FLFP{i}" for i in range(1,6)] +
    [f"II{i}"   for i in range(1,6)] +
    [f"PEE{i}"  for i in range(1,6)] +
    [f"EG{i}"   for i in range(1,6)]
)
item_data = np.hstack([GBEI_data, FLFP_data, II_data, PEE_data, EG_data])

df = pd.DataFrame(item_data, columns=item_cols)
df.insert(0, "ID", range(1, N+1))
df.insert(1, "Location",   location)
df.insert(2, "Gender",     gender)
df.insert(3, "Age",        age)
df.insert(4, "Education",  education)
df.insert(5, "Occupation", occupation)
df.insert(6, "Income",     income)
df.insert(7, "EthnicMinority", ethnic)
df.insert(8, "HH_Size",    hh_size)
df.insert(9, "Internet",   internet)
df.insert(10,"DistToSchool",dist_school)
df.insert(11,"FLFP_HH",    flfp_hh)

df.to_excel(writer, sheet_name="Survey_Data", index=False)
df.to_csv(os.path.join(OUT, "Survey_Data.csv"), index=False)
print(f"  → Survey data generated: {N} respondents, {df.shape[1]} columns")
print(f"  → Saved Survey_Data.csv")

# construct composite scores (mean)
df["GBEI"] = df[[f"GBEI{i}" for i in range(1,6)]].mean(axis=1)
df["FLFP"] = df[[f"FLFP{i}" for i in range(1,6)]].mean(axis=1)
df["II"]   = df[[f"II{i}"   for i in range(1,6)]].mean(axis=1)
df["PEE"]  = df[[f"PEE{i}"  for i in range(1,6)]].mean(axis=1)
df["EG"]   = df[[f"EG{i}"   for i in range(1,6)]].mean(axis=1)

# interaction term (mean-centered)
df["GBEI_c"] = df["GBEI"] - df["GBEI"].mean()
df["PEE_c"]  = df["PEE"]  - df["PEE"].mean()
df["GBEI_PEE"] = df["GBEI_c"] * df["PEE_c"]

# =============================================================================
# 2.  DEMOGRAPHIC ANALYSIS
# =============================================================================
print("\n" + "=" * 70)
print(" STEP 2 – DEMOGRAPHIC ANALYSIS")
print("=" * 70)

demo_vars = {
    "Gender":       "Gender",
    "Age":          "Age",
    "Location":     "Location",
    "Education":    "Education",
    "Occupation":   "Occupation",
    "Income":       "Income",
    "EthnicMinority":"EthnicMinority",
    "HH_Size":      "HH_Size",
    "Internet":     "Internet",
    "DistToSchool": "DistToSchool",
    "FLFP_HH":      "FLFP_HH",
}
demo_rows = []
for label, col in demo_vars.items():
    vc = df[col].value_counts()
    pct = df[col].value_counts(normalize=True) * 100
    for cat in vc.index:
        demo_rows.append({
            "Variable": label,
            "Category": cat,
            "Frequency": int(vc[cat]),
            "Percentage (%)": round(float(pct[cat]), 1)
        })
demo_df = pd.DataFrame(demo_rows)
demo_df.to_excel(writer, sheet_name="Demographic_Analysis", index=False)
print("  → Demographic table saved")

# plot demographics (bar charts grid)
fig, axes = plt.subplots(3, 4, figsize=(22, 15))
axes = axes.flatten()
for ax_idx, (label, col) in enumerate(demo_vars.items()):
    if ax_idx >= len(axes): break
    vc  = df[col].value_counts()
    pct = df[col].value_counts(normalize=True)*100
    bars = axes[ax_idx].bar(range(len(vc)), vc.values,
                            color=sns.color_palette("muted", len(vc)))
    axes[ax_idx].set_xticks(range(len(vc)))
    axes[ax_idx].set_xticklabels(vc.index, rotation=30, ha="right", fontsize=8)
    axes[ax_idx].set_title(label, fontweight="bold", fontsize=10)
    axes[ax_idx].set_ylabel("Count")
    for bar, p in zip(bars, pct.values):
        axes[ax_idx].text(bar.get_x()+bar.get_width()/2,
                          bar.get_height()+1, f"{p:.1f}%",
                          ha="center", va="bottom", fontsize=7)
# hide unused
for idx in range(len(demo_vars), len(axes)):
    axes[idx].set_visible(False)
plt.suptitle("Demographic Profile of Respondents (N = 400)",
             fontsize=14, fontweight="bold", y=1.01)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig1_Demographic_Analysis.png"))
plt.close()
print("  → Fig1_Demographic_Analysis.png saved")

# =============================================================================
# 3.  DESCRIPTIVE STATISTICS
# =============================================================================
print("\n" + "=" * 70)
print(" STEP 3 – DESCRIPTIVE STATISTICS")
print("=" * 70)

constructs_items = {
    "GBEI": [f"GBEI{i}" for i in range(1,6)],
    "FLFP": [f"FLFP{i}" for i in range(1,6)],
    "II":   [f"II{i}"   for i in range(1,6)],
    "PEE":  [f"PEE{i}"  for i in range(1,6)],
    "EG":   [f"EG{i}"   for i in range(1,6)],
}

desc_rows = []
all_items = [item for items in constructs_items.values() for item in items]
for item in all_items:
    s = df[item]
    desc_rows.append({
        "Item": item,
        "N": len(s),
        "Min": s.min(),
        "Max": s.max(),
        "Mean": round(s.mean(), 3),
        "SD": round(s.std(), 3),
        "Skewness": round(s.skew(), 3),
        "Kurtosis": round(s.kurtosis(), 3),
    })
desc_df = pd.DataFrame(desc_rows)
desc_df.to_excel(writer, sheet_name="Descriptive_Statistics", index=False)
print("  → Descriptive statistics saved")

# mean + SD bar chart per construct
fig, ax = plt.subplots(figsize=(16, 6))
x  = np.arange(len(all_items))
means = desc_df["Mean"].values
sds   = desc_df["SD"].values
colors = []
palette = sns.color_palette("Set2", 5)
for i, (c, items) in enumerate(constructs_items.items()):
    colors.extend([palette[i]] * len(items))

bars = ax.bar(x, means, yerr=sds, capsize=4, color=colors,
              edgecolor="black", linewidth=0.6, alpha=0.85)
ax.set_xticks(x)
ax.set_xticklabels(all_items, rotation=45, ha="right", fontsize=9)
ax.set_ylabel("Mean (Likert Scale 1-5)")
ax.set_ylim(1, 6)
ax.set_title("Descriptive Statistics – Mean ± SD for All Items",
             fontweight="bold")
legend_patches = [mpatches.Patch(color=palette[i], label=c)
                  for i,c in enumerate(constructs_items.keys())]
ax.legend(handles=legend_patches, title="Construct", loc="upper right")
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig2_Descriptive_Statistics.png"))
plt.close()
print("  → Fig2_Descriptive_Statistics.png saved")

# =============================================================================
# 4.  RELIABILITY ANALYSIS (Cronbach α & Composite Reliability)
# =============================================================================
print("\n" + "=" * 70)
print(" STEP 4 – RELIABILITY ANALYSIS")
print("=" * 70)

def cronbach_alpha(df_items):
    k    = df_items.shape[1]
    item_vars = df_items.var(ddof=1, axis=0)
    total_var = df_items.sum(axis=1).var(ddof=1)
    alpha = (k / (k - 1)) * (1 - item_vars.sum() / total_var)
    return round(float(alpha), 4)

def composite_reliability(loadings):
    """CR = (Σλ)² / [(Σλ)² + Σ(1-λ²)]"""
    l = np.array(loadings)
    return round(float(l.sum()**2 / (l.sum()**2 + (1 - l**2).sum())), 4)

# get standardised loadings via unit-weight PCA proxy
from sklearn.decomposition import PCA

rel_rows = []
loadings_dict = {}
for c, items in constructs_items.items():
    sub = df[items].astype(float)
    alpha = cronbach_alpha(sub)
    # first principal component loadings as proxy for SEM loadings
    pca  = PCA(n_components=1)
    pca.fit(sub)
    loads = np.abs(pca.components_[0])
    cr    = composite_reliability(loads)
    # AVE
    ave   = round(float((loads**2).mean()), 4)
    rel_rows.append({
        "Construct": c,
        "Items": ", ".join(items),
        "Cronbach's α": alpha,
        "Composite Reliability (CR)": cr,
        "AVE": ave,
    })
    loadings_dict[c] = dict(zip(items, [round(l,3) for l in loads]))
    print(f"  {c:5s} | α = {alpha} | CR = {cr} | AVE = {ave}")

rel_df = pd.DataFrame(rel_rows)
rel_df.to_excel(writer, sheet_name="Reliability_Analysis", index=False)
print("  → Reliability table saved")

# loadings table
load_rows = []
for c, items in constructs_items.items():
    for item in items:
        load_rows.append({
            "Construct": c,
            "Item": item,
            "Standardized Loading": loadings_dict[c][item]
        })
load_df = pd.DataFrame(load_rows)
load_df.to_excel(writer, sheet_name="Factor_Loadings", index=False)
print("  → Factor loadings saved")

# bar chart of α values
fig, ax = plt.subplots(figsize=(8, 5))
constructs_list = list(constructs_items.keys())
alpha_vals = [rel_df.loc[rel_df.Construct==c, "Cronbach's α"].values[0]
              for c in constructs_list]
bars = ax.barh(constructs_list, alpha_vals,
               color=sns.color_palette("deep", len(constructs_list)),
               edgecolor="black", linewidth=0.6)
ax.axvline(0.85, color="red", linestyle="--", linewidth=1.5, label="α = 0.85 threshold")
ax.axvline(0.70, color="orange", linestyle=":", linewidth=1.5, label="α = 0.70 threshold")
ax.set_xlim(0, 1.05)
ax.set_xlabel("Cronbach's Alpha")
ax.set_title("Reliability Analysis – Cronbach's Alpha per Construct",
             fontweight="bold")
for bar, val in zip(bars, alpha_vals):
    ax.text(val + 0.01, bar.get_y() + bar.get_height()/2,
            f"{val:.4f}", va="center", fontsize=10)
ax.legend()
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig3_Reliability_Cronbach_Alpha.png"))
plt.close()
print("  → Fig3_Reliability_Cronbach_Alpha.png saved")

# heatmap of item loadings
load_matrix = pd.DataFrame(0.0, index=all_items,
                            columns=list(constructs_items.keys()))
for c, items in constructs_items.items():
    for item in items:
        load_matrix.loc[item, c] = loadings_dict[c][item]

fig, ax = plt.subplots(figsize=(8, 11))
sns.heatmap(load_matrix, annot=True, fmt=".3f", cmap="Blues",
            linewidths=0.5, ax=ax, vmin=0, vmax=1)
ax.set_title("Factor Loadings – Measurement Model", fontweight="bold")
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig4_Factor_Loadings_Heatmap.png"))
plt.close()
print("  → Fig4_Factor_Loadings_Heatmap.png saved")

# =============================================================================
# 5.  CONVERGENT & DISCRIMINANT VALIDITY (HTMT)
# =============================================================================
print("\n" + "=" * 70)
print(" STEP 5 – VALIDITY ANALYSIS")
print("=" * 70)

construct_scores = df[["GBEI","FLFP","II","PEE","EG"]]

# Pearson correlation matrix
corr_mat = construct_scores.corr()
corr_mat.to_excel(writer, sheet_name="Correlation_Matrix")
print("  → Correlation matrix saved")

# HTMT (Heterotrait-Monotrait Ratio of Correlations)
def htmt_ratio(df_constructs, constructs_items):
    keys = list(constructs_items.keys())
    htmt_df = pd.DataFrame(np.nan, index=keys, columns=keys)
    for i, j in itertools.combinations(range(len(keys)), 2):
        ci, cj = keys[i], keys[j]
        items_i, items_j = constructs_items[ci], constructs_items[cj]
        sub_i = df_constructs[items_i].astype(float)
        sub_j = df_constructs[items_j].astype(float)
        # hetero-trait cross-correlations
        cross = []
        for a in items_i:
            for b in items_j:
                cross.append(df_constructs[[a, b]].corr().iloc[0,1])
        hetero = np.mean(cross)
        # mono-trait (within construct) correlations
        def mono_mean(items):
            pairs = list(itertools.combinations(items, 2))
            vals  = [df_constructs[[a,b]].corr().iloc[0,1] for a,b in pairs]
            return np.mean(vals)
        mono_i = mono_mean(items_i)
        mono_j = mono_mean(items_j)
        htmt   = hetero / np.sqrt(mono_i * mono_j)
        htmt_df.loc[ci, cj] = round(htmt, 3)
        htmt_df.loc[cj, ci] = round(htmt, 3)
    return htmt_df

htmt_df = htmt_ratio(df, constructs_items)
htmt_df.to_excel(writer, sheet_name="HTMT_Discriminant_Validity")
print("  → HTMT table saved")

# correlation heatmap
fig, axes = plt.subplots(1, 2, figsize=(16, 7))
mask = np.triu(np.ones_like(corr_mat, dtype=bool))
sns.heatmap(corr_mat, annot=True, fmt=".3f", cmap="coolwarm",
            center=0, linewidths=0.5, ax=axes[0],
            mask=mask, vmin=-1, vmax=1)
axes[0].set_title("Construct Correlation Matrix\n(Lower Triangle)",
                  fontweight="bold")

mask_htmt = np.tril(np.ones_like(htmt_df.values, dtype=bool))
htmt_num = htmt_df.fillna(0).astype(float)
sns.heatmap(htmt_num, annot=True, fmt=".3f", cmap="YlOrRd",
            linewidths=0.5, ax=axes[1], vmin=0, vmax=1)
axes[1].set_title("HTMT Discriminant Validity\n(< 0.85 = adequate)",
                  fontweight="bold")
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig5_Correlation_HTMT.png"))
plt.close()
print("  → Fig5_Correlation_HTMT.png saved")

# =============================================================================
# 6.  COLLINEARITY (VIF)
# =============================================================================
print("\n" + "=" * 70)
print(" STEP 6 – COLLINEARITY (VIF)")
print("=" * 70)

X_vif = df[["GBEI","FLFP","II","PEE"]].copy()
X_vif = sm.add_constant(X_vif)
vif_rows = []
for col in X_vif.columns:
    if col == "const": continue
    vif_val = variance_inflation_factor(X_vif.values, X_vif.columns.tolist().index(col))
    vif_rows.append({"Predictor": col, "VIF": round(vif_val, 3)})
vif_df = pd.DataFrame(vif_rows)
vif_df.to_excel(writer, sheet_name="Collinearity_VIF", index=False)
print(vif_df.to_string(index=False))
print("  → VIF table saved")

# =============================================================================
# 7.  MEASUREMENT MODEL – AVE & CR SUMMARY FIGURE
# =============================================================================
print("\n" + "=" * 70)
print(" STEP 7 – MEASUREMENT MODEL FIGURE")
print("=" * 70)

fig, axes = plt.subplots(1, 3, figsize=(18, 6))
palette_mm = sns.color_palette("Set2", len(constructs_list))

# (a) Alpha
axes[0].bar(constructs_list,
            [rel_df.loc[rel_df.Construct==c,"Cronbach's α"].values[0] for c in constructs_list],
            color=palette_mm, edgecolor="k", linewidth=0.6)
axes[0].axhline(0.85, color="red", linestyle="--", linewidth=1.5)
axes[0].set_ylim(0, 1.1)
axes[0].set_title("Cronbach's Alpha", fontweight="bold")
axes[0].set_ylabel("Value")

# (b) CR
axes[1].bar(constructs_list,
            [rel_df.loc[rel_df.Construct==c,"Composite Reliability (CR)"].values[0] for c in constructs_list],
            color=palette_mm, edgecolor="k", linewidth=0.6)
axes[1].axhline(0.70, color="green", linestyle="--", linewidth=1.5, label="CR ≥ 0.70")
axes[1].set_ylim(0, 1.1)
axes[1].set_title("Composite Reliability (CR)", fontweight="bold")

# (c) AVE
axes[2].bar(constructs_list,
            [rel_df.loc[rel_df.Construct==c,"AVE"].values[0] for c in constructs_list],
            color=palette_mm, edgecolor="k", linewidth=0.6)
axes[2].axhline(0.50, color="blue", linestyle="--", linewidth=1.5, label="AVE ≥ 0.50")
axes[2].set_ylim(0, 1.1)
axes[2].set_title("Average Variance Extracted (AVE)", fontweight="bold")

for ax in axes:
    ax.set_xticklabels(constructs_list, rotation=20, ha="right")
    for bar in ax.patches:
        ax.text(bar.get_x()+bar.get_width()/2,
                bar.get_height()+0.01,
                f"{bar.get_height():.3f}",
                ha="center", va="bottom", fontsize=9)
plt.suptitle("Measurement Model – Reliability & Validity Indicators",
             fontweight="bold", fontsize=13)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig6_Measurement_Model_Indicators.png"))
plt.close()
print("  → Fig6_Measurement_Model_Indicators.png saved")

# =============================================================================
# 8.  SEM STRUCTURAL MODEL (OLS path equations)
# =============================================================================
print("\n" + "=" * 70)
print(" STEP 8 – SEM STRUCTURAL MODEL")
print("=" * 70)

# --- Path 1: GBEI → EG (H1 direct) ---
X1 = sm.add_constant(df["GBEI"])
m1 = sm.OLS(df["EG"], X1).fit()
b_gbei_eg  = m1.params["GBEI"]
p_gbei_eg  = m1.pvalues["GBEI"]
r2_h1      = m1.rsquared

# --- Path 2: GBEI → FLFP (H2a) ---
X2 = sm.add_constant(df["GBEI"])
m2 = sm.OLS(df["FLFP"], X2).fit()
b_gbei_flfp = m2.params["GBEI"]
p_gbei_flfp = m2.pvalues["GBEI"]

# --- Path 3: FLFP → EG controlling GBEI (H2b) ---
X3 = sm.add_constant(df[["GBEI","FLFP"]])
m3 = sm.OLS(df["EG"], X3).fit()
b_flfp_eg   = m3.params["FLFP"]
p_flfp_eg   = m3.pvalues["FLFP"]
b_gbei_eg_m2 = m3.params["GBEI"]
r2_h2       = m3.rsquared

# --- Path 4: GBEI → II (H3a) ---
X4 = sm.add_constant(df["GBEI"])
m4 = sm.OLS(df["II"], X4).fit()
b_gbei_ii   = m4.params["GBEI"]
p_gbei_ii   = m4.pvalues["GBEI"]

# --- Path 5: II → EG controlling GBEI (H3b) ---
X5 = sm.add_constant(df[["GBEI","II"]])
m5 = sm.OLS(df["EG"], X5).fit()
b_ii_eg     = m5.params["II"]
p_ii_eg     = m5.pvalues["II"]
r2_h3       = m5.rsquared

# --- Path 6: Moderation GBEI×PEE → EG (H4) ---
X6 = sm.add_constant(df[["GBEI_c","PEE_c","GBEI_PEE"]])
m6 = sm.OLS(df["EG"], X6).fit()
b_gbei_mod   = m6.params["GBEI_c"]
b_pee_mod    = m6.params["PEE_c"]
b_interact   = m6.params["GBEI_PEE"]
p_interact   = m6.pvalues["GBEI_PEE"]
r2_h4        = m6.rsquared

# --- Full structural model ---
X_full = sm.add_constant(df[["GBEI","FLFP","II","PEE"]])
m_full = sm.OLS(df["EG"], X_full).fit()
r2_full = m_full.rsquared

print(f"  H1 Direct:  β(GBEI→EG)  = {b_gbei_eg:.4f}, p = {p_gbei_eg:.4f}, R² = {r2_h1:.4f}")
print(f"  H2a path:   β(GBEI→FLFP)= {b_gbei_flfp:.4f}, p = {p_gbei_flfp:.4f}")
print(f"  H2b path:   β(FLFP→EG)  = {b_flfp_eg:.4f}, p = {p_flfp_eg:.4f}, R² = {r2_h2:.4f}")
print(f"  H3a path:   β(GBEI→II)  = {b_gbei_ii:.4f}, p = {p_gbei_ii:.4f}")
print(f"  H3b path:   β(II→EG)    = {b_ii_eg:.4f}, p = {p_ii_eg:.4f}, R² = {r2_h3:.4f}")
print(f"  H4 Interact:β(GBEI×PEE) = {b_interact:.4f}, p = {p_interact:.4f}, R² = {r2_h4:.4f}")
print(f"  Full Model: R²(EG)      = {r2_full:.4f}")

# compile structural path table
struct_rows = [
    {"Hypothesis": "H1",  "Path": "GBEI → EG", "β": round(b_gbei_eg,4),   "SE": round(m1.bse["GBEI"],4),   "t": round(m1.tvalues["GBEI"],4),   "p-value": round(p_gbei_eg,4),   "R²": round(r2_h1,4), "Support": "Yes" if p_gbei_eg<0.05 else "No"},
    {"Hypothesis": "H2a", "Path": "GBEI → FLFP","β": round(b_gbei_flfp,4), "SE": round(m2.bse["GBEI"],4),   "t": round(m2.tvalues["GBEI"],4),   "p-value": round(p_gbei_flfp,4), "R²": round(m2.rsquared,4), "Support": "Yes" if p_gbei_flfp<0.05 else "No"},
    {"Hypothesis": "H2b", "Path": "FLFP → EG", "β": round(b_flfp_eg,4),   "SE": round(m3.bse["FLFP"],4),   "t": round(m3.tvalues["FLFP"],4),   "p-value": round(p_flfp_eg,4),   "R²": round(r2_h2,4), "Support": "Yes" if p_flfp_eg<0.05 else "No"},
    {"Hypothesis": "H3a", "Path": "GBEI → II",  "β": round(b_gbei_ii,4),   "SE": round(m4.bse["GBEI"],4),   "t": round(m4.tvalues["GBEI"],4),   "p-value": round(p_gbei_ii,4),   "R²": round(m4.rsquared,4), "Support": "Yes" if p_gbei_ii<0.05 else "No"},
    {"Hypothesis": "H3b", "Path": "II → EG",   "β": round(b_ii_eg,4),     "SE": round(m5.bse["II"],4),     "t": round(m5.tvalues["II"],4),     "p-value": round(p_ii_eg,4),     "R²": round(r2_h3,4), "Support": "Yes" if p_ii_eg<0.05 else "No"},
    {"Hypothesis": "H4",  "Path": "GBEI×PEE → EG","β": round(b_interact,4),"SE": round(m6.bse["GBEI_PEE"],4),"t": round(m6.tvalues["GBEI_PEE"],4),"p-value": round(p_interact,4), "R²": round(r2_h4,4), "Support": "Yes" if p_interact<0.05 else "No"},
]
struct_df = pd.DataFrame(struct_rows)
struct_df.to_excel(writer, sheet_name="Structural_Path_Coefficients", index=False)
print("  → Structural path table saved")

# Effect size f²
def f2(r2_full, r2_reduced):
    return round((r2_full - r2_reduced) / (1 - r2_full), 4)

f2_gbei  = f2(r2_h1,  0)
f2_flfp  = f2(r2_h2,  r2_h1)
f2_ii    = f2(r2_h3,  r2_h1)
f2_pee   = f2(r2_h4,  r2_h1)

ef_df = pd.DataFrame([
    {"Path": "GBEI → EG",    "R²(full)": r2_h1,  "R²(excl.)": 0,       "f²": f2_gbei},
    {"Path": "FLFP → EG",    "R²(full)": r2_h2,  "R²(excl.)": r2_h1,   "f²": f2_flfp},
    {"Path": "II → EG",      "R²(full)": r2_h3,  "R²(excl.)": r2_h1,   "f²": f2_ii},
    {"Path": "GBEI×PEE → EG","R²(full)": r2_h4,  "R²(excl.)": r2_h1,   "f²": f2_pee},
])
ef_df.to_excel(writer, sheet_name="Effect_Size_f2", index=False)
print("  → Effect size f² table saved")

# =============================================================================
# 9.  BOOTSTRAPPING – MEDIATION & MODERATION
# =============================================================================
print("\n" + "=" * 70)
print(" STEP 9 – BOOTSTRAPPING ANALYSIS")
print("=" * 70)

n_boot = 2000

def bootstrap_indirect(df, x, m, y, n_boot=2000):
    """Bootstrap indirect effect (Sobel/BC-CI) for x→m→y."""
    indirect = []
    for _ in range(n_boot):
        idx    = np.random.choice(len(df), len(df), replace=True)
        df_b   = df.iloc[idx]
        a_coef = sm.OLS(df_b[m], sm.add_constant(df_b[x])).fit().params[x]
        b_coef = sm.OLS(df_b[y], sm.add_constant(df_b[[x, m]])).fit().params[m]
        indirect.append(a_coef * b_coef)
    indirect = np.array(indirect)
    ci_lo, ci_hi = np.percentile(indirect, [2.5, 97.5])
    return round(np.mean(indirect),4), round(ci_lo,4), round(ci_hi,4)

def bootstrap_moderation(df, x, z, xz, y, n_boot=2000):
    """Bootstrap interaction coefficient for x×z→y."""
    coefs = []
    for _ in range(n_boot):
        idx  = np.random.choice(len(df), len(df), replace=True)
        df_b = df.iloc[idx]
        coef = sm.OLS(df_b[y], sm.add_constant(df_b[[x,z,xz]])).fit().params[xz]
        coefs.append(coef)
    coefs = np.array(coefs)
    ci_lo, ci_hi = np.percentile(coefs, [2.5, 97.5])
    return round(np.mean(coefs),4), round(ci_lo,4), round(ci_hi,4)

# H2 mediation: GBEI → FLFP → EG
ie_h2, ci_lo_h2, ci_hi_h2 = bootstrap_indirect(df, "GBEI", "FLFP", "EG", n_boot)
# H3 mediation: GBEI → II → EG
ie_h3, ci_lo_h3, ci_hi_h3 = bootstrap_indirect(df, "GBEI", "II",   "EG", n_boot)
# H4 moderation: GBEI×PEE → EG
ie_h4, ci_lo_h4, ci_hi_h4 = bootstrap_moderation(df, "GBEI_c","PEE_c","GBEI_PEE","EG",n_boot)

boot_df = pd.DataFrame([
    {"Hypothesis":"H2","Effect": "Indirect: GBEI→FLFP→EG",
     "β": ie_h2, "95% CI Lower": ci_lo_h2, "95% CI Upper": ci_hi_h2,
     "Significant (CI excl. 0)": "Yes" if ci_lo_h2*ci_hi_h2>0 else "No"},
    {"Hypothesis":"H3","Effect": "Indirect: GBEI→II→EG",
     "β": ie_h3, "95% CI Lower": ci_lo_h3, "95% CI Upper": ci_hi_h3,
     "Significant (CI excl. 0)": "Yes" if ci_lo_h3*ci_hi_h3>0 else "No"},
    {"Hypothesis":"H4","Effect": "Interaction: GBEI×PEE→EG",
     "β": ie_h4, "95% CI Lower": ci_lo_h4, "95% CI Upper": ci_hi_h4,
     "Significant (CI excl. 0)": "Yes" if ci_lo_h4*ci_hi_h4>0 else "No"},
])
boot_df.to_excel(writer, sheet_name="Bootstrap_Mediation_Moderation", index=False)
print(boot_df.to_string(index=False))
print("  → Bootstrap table saved")

# =============================================================================
# 10.  HYPOTHESIS SUMMARY TABLE
# =============================================================================
print("\n" + "=" * 70)
print(" STEP 10 – HYPOTHESIS SUMMARY")
print("=" * 70)

hyp_df = pd.DataFrame([
    {"Hypothesis": "H1",
     "Statement": "GBEI negatively affects EG",
     "β / IE": b_gbei_eg,
     "p-value": p_gbei_eg,
     "95% CI": f"[{round(m1.conf_int().loc['GBEI',0],3)}, {round(m1.conf_int().loc['GBEI',1],3)}]",
     "Result": "Supported" if p_gbei_eg<0.05 else "Not Supported"},
    {"Hypothesis": "H2",
     "Statement": "FLFP mediates GBEI → EG",
     "β / IE": ie_h2,
     "p-value": "Bootstrap",
     "95% CI": f"[{ci_lo_h2}, {ci_hi_h2}]",
     "Result": "Supported" if ci_lo_h2*ci_hi_h2>0 else "Not Supported"},
    {"Hypothesis": "H3",
     "Statement": "II mediates GBEI → EG",
     "β / IE": ie_h3,
     "p-value": "Bootstrap",
     "95% CI": f"[{ci_lo_h3}, {ci_hi_h3}]",
     "Result": "Supported" if ci_lo_h3*ci_hi_h3>0 else "Not Supported"},
    {"Hypothesis": "H4",
     "Statement": "PEE moderates GBEI → EG",
     "β / IE": b_interact,
     "p-value": p_interact,
     "95% CI": f"[{ci_lo_h4}, {ci_hi_h4}]",
     "Result": "Supported" if p_interact<0.05 else "Not Supported"},
])
hyp_df.to_excel(writer, sheet_name="Hypothesis_Summary", index=False)
print(hyp_df.to_string(index=False))
print("  → Hypothesis summary saved")

# =============================================================================
# 11.  SEM PATH DIAGRAM
# =============================================================================
print("\n" + "=" * 70)
print(" STEP 11 – SEM PATH DIAGRAM")
print("=" * 70)

def sig_star(p):
    if   p < 0.001: return "***"
    elif p < 0.01:  return "**"
    elif p < 0.05:  return "*"
    else:           return "ns"

def draw_arrow(ax, start, end, color="black", lw=1.5,
               label=None, label_offset=(0,0), style="->"):
    ax.annotate("", xy=end, xytext=start,
                arrowprops=dict(arrowstyle=style, color=color,
                                lw=lw, connectionstyle="arc3,rad=0.0"))
    if label:
        mx = (start[0]+end[0])/2 + label_offset[0]
        my = (start[1]+end[1])/2 + label_offset[1]
        ax.text(mx, my, label, ha="center", va="center",
                fontsize=8.5, color=color, fontweight="bold",
                bbox=dict(boxstyle="round,pad=0.2", fc="white", alpha=0.8, ec=color))

fig, ax = plt.subplots(figsize=(16, 10))
ax.set_xlim(0, 10)
ax.set_ylim(0, 7)
ax.axis("off")
ax.set_facecolor("#f8f9fa")
fig.patch.set_facecolor("#f8f9fa")

# node positions
pos = {
    "GBEI": (2.0, 3.5),
    "FLFP": (5.5, 5.5),
    "II":   (5.5, 1.5),
    "PEE":  (5.5, 3.5),
    "EG":   (8.5, 3.5),
}

node_colors = {
    "GBEI": "#E74C3C",   # red – IV
    "FLFP": "#3498DB",   # blue – mediator 1
    "II":   "#27AE60",   # green – mediator 2
    "PEE":  "#9B59B6",   # purple – moderator
    "EG":   "#F39C12",   # orange – DV
}
node_labels = {
    "GBEI": "Gender-Based\nEducational\nInequality\n(GBEI)",
    "FLFP": "Female Labour\nForce Participation\n(FLFP)",
    "II":   "Income\nInequality\n(II)",
    "PEE":  "Public Expenditure\non Education\n(PEE)",
    "EG":   "Economic\nGrowth\n(EG)",
}

for node, (x, y) in pos.items():
    circle = plt.Circle((x, y), 0.85,
                         color=node_colors[node], alpha=0.15,
                         linewidth=2, edgecolor=node_colors[node], zorder=3)
    ax.add_patch(circle)
    ax.text(x, y, node_labels[node], ha="center", va="center",
            fontsize=8.5, fontweight="bold", color=node_colors[node],
            zorder=4, multialignment="center")

# H1: GBEI → EG (direct, negative)
p1 = pos["GBEI"]; p2 = pos["EG"]
ax.annotate("", xy=(p2[0]-0.9, p2[1]+0.1), xytext=(p1[0]+0.9, p1[1]+0.1),
            arrowprops=dict(arrowstyle="->", color="#E74C3C", lw=2.5,
                            connectionstyle="arc3,rad=0.0"),
            zorder=2)
lbl = f"β={b_gbei_eg:.3f}{sig_star(p_gbei_eg)}\n(H1 Direct)"
ax.text(5.25, 3.9, lbl, ha="center", va="center", fontsize=8,
        color="#E74C3C", fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.25", fc="white", alpha=0.9, ec="#E74C3C"))

# H2a: GBEI → FLFP
ax.annotate("", xy=(pos["FLFP"][0]-0.9, pos["FLFP"][1]-0.2),
            xytext=(pos["GBEI"][0]+0.6, pos["GBEI"][1]+0.6),
            arrowprops=dict(arrowstyle="->", color="#3498DB", lw=2.0,
                            connectionstyle="arc3,rad=0.0"), zorder=2)
ax.text(3.5, 4.9, f"β={b_gbei_flfp:.3f}{sig_star(p_gbei_flfp)}",
        ha="center", va="center", fontsize=8, color="#3498DB", fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.2", fc="white", alpha=0.9, ec="#3498DB"))

# H2b: FLFP → EG
ax.annotate("", xy=(pos["EG"][0]-0.9, pos["EG"][1]+0.3),
            xytext=(pos["FLFP"][0]+0.7, pos["FLFP"][1]-0.3),
            arrowprops=dict(arrowstyle="->", color="#3498DB", lw=2.0,
                            connectionstyle="arc3,rad=0.0"), zorder=2)
ax.text(7.3, 5.0, f"β={b_flfp_eg:.3f}{sig_star(p_flfp_eg)}",
        ha="center", va="center", fontsize=8, color="#3498DB", fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.2", fc="white", alpha=0.9, ec="#3498DB"))

# H3a: GBEI → II
ax.annotate("", xy=(pos["II"][0]-0.9, pos["II"][1]+0.2),
            xytext=(pos["GBEI"][0]+0.6, pos["GBEI"][1]-0.6),
            arrowprops=dict(arrowstyle="->", color="#27AE60", lw=2.0,
                            connectionstyle="arc3,rad=0.0"), zorder=2)
ax.text(3.5, 2.1, f"β={b_gbei_ii:.3f}{sig_star(p_gbei_ii)}",
        ha="center", va="center", fontsize=8, color="#27AE60", fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.2", fc="white", alpha=0.9, ec="#27AE60"))

# H3b: II → EG
ax.annotate("", xy=(pos["EG"][0]-0.9, pos["EG"][1]-0.3),
            xytext=(pos["II"][0]+0.7, pos["II"][1]+0.3),
            arrowprops=dict(arrowstyle="->", color="#27AE60", lw=2.0,
                            connectionstyle="arc3,rad=0.0"), zorder=2)
ax.text(7.3, 2.0, f"β={b_ii_eg:.3f}{sig_star(p_ii_eg)}",
        ha="center", va="center", fontsize=8, color="#27AE60", fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.2", fc="white", alpha=0.9, ec="#27AE60"))

# H4: PEE → EG (moderation dashed)
ax.annotate("", xy=(pos["EG"][0]-0.9, pos["EG"][1]-0.05),
            xytext=(pos["PEE"][0]+0.9, pos["PEE"][1]),
            arrowprops=dict(arrowstyle="->", color="#9B59B6", lw=2.0,
                            linestyle="dashed",
                            connectionstyle="arc3,rad=0.0"), zorder=2)
ax.text(7.1, 3.35, f"Mod: β={b_interact:.3f}{sig_star(p_interact)}\n(H4)",
        ha="center", va="center", fontsize=8, color="#9B59B6", fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.2", fc="white", alpha=0.9, ec="#9B59B6"))

# moderation symbol (×) between GBEI and PEE
ax.text(3.5, 3.5, "×", ha="center", va="center", fontsize=20,
        color="#9B59B6", fontweight="bold", zorder=5)
ax.annotate("", xy=(pos["PEE"][0]-0.9, pos["PEE"][1]),
            xytext=(pos["GBEI"][0]+0.9, pos["GBEI"][1]),
            arrowprops=dict(arrowstyle="->", color="#9B59B6", lw=1.5,
                            linestyle="dotted",
                            connectionstyle="arc3,rad=0.0"), zorder=2)

# R² annotation on EG
ax.text(pos["EG"][0], pos["EG"][1]-1.3, f"R² = {r2_full:.3f}",
        ha="center", va="center", fontsize=9, fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.3", fc="#F39C12", alpha=0.2, ec="#F39C12"))

# legend
legend_elements = [
    mpatches.Patch(fc="#E74C3C", alpha=0.6, label="IV – GBEI"),
    mpatches.Patch(fc="#3498DB", alpha=0.6, label="Mediator 1 – FLFP (H2)"),
    mpatches.Patch(fc="#27AE60", alpha=0.6, label="Mediator 2 – II (H3)"),
    mpatches.Patch(fc="#9B59B6", alpha=0.6, label="Moderator – PEE (H4)"),
    mpatches.Patch(fc="#F39C12", alpha=0.6, label="DV – Economic Growth"),
    mpatches.Patch(fc="white", ec="black",  label="*** p<.001  ** p<.01  * p<.05"),
]
ax.legend(handles=legend_elements, loc="lower left",
          fontsize=8.5, framealpha=0.9, title="Legend")

ax.set_title("SEM Path Diagram – Gender Inequality, Education & Economic Growth\n"
             "(Structural Equation Model with Mediation & Moderation)",
             fontsize=13, fontweight="bold", pad=10)

plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig7_SEM_Path_Diagram.png"), dpi=200)
plt.close()
print("  → Fig7_SEM_Path_Diagram.png saved")

# =============================================================================
# 12.  MEDIATION PLOTS
# =============================================================================
print("\n" + "=" * 70)
print(" STEP 12 – MEDIATION PLOTS")
print("=" * 70)

def mediation_diagram(fig_path, title, x_lbl, m_lbl, y_lbl,
                      a, b, c_prime, indirect, ci_lo, ci_hi,
                      p_a, p_b, p_c):
    fig, ax = plt.subplots(figsize=(12, 7))
    ax.set_xlim(0, 10); ax.set_ylim(0, 7); ax.axis("off")
    ax.set_facecolor("#f8f9fa")
    fig.patch.set_facecolor("#f8f9fa")
    # boxes
    for (cx,cy,lbl,col) in [
        (1.5, 3.5, x_lbl, "#E74C3C"),
        (5.0, 5.5, m_lbl, "#3498DB"),
        (8.5, 3.5, y_lbl, "#F39C12"),
    ]:
        rect = plt.Rectangle((cx-1.3,cy-0.7), 2.6, 1.4,
                              color=col, alpha=0.15,
                              linewidth=2, edgecolor=col, zorder=3)
        ax.add_patch(rect)
        ax.text(cx, cy, lbl, ha="center", va="center",
                fontsize=10, fontweight="bold", color=col, zorder=4)
    # a path
    ax.annotate("", xy=(3.65,5.5), xytext=(2.85, 4.2),
                arrowprops=dict(arrowstyle="->",color="#3498DB",lw=2.2), zorder=2)
    ax.text(3.0, 5.0, f"a = {a:.3f}{sig_star(p_a)}",
            ha="center", fontsize=10, color="#3498DB", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.2",fc="white",alpha=0.9,ec="#3498DB"))
    # b path
    ax.annotate("", xy=(7.15, 4.2), xytext=(6.35, 5.5),
                arrowprops=dict(arrowstyle="->",color="#3498DB",lw=2.2), zorder=2)
    ax.text(7.3, 5.0, f"b = {b:.3f}{sig_star(p_b)}",
            ha="center", fontsize=10, color="#3498DB", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.2",fc="white",alpha=0.9,ec="#3498DB"))
    # c' direct path
    ax.annotate("", xy=(7.15,3.5), xytext=(2.85,3.5),
                arrowprops=dict(arrowstyle="->",color="#E74C3C",lw=2.2), zorder=2)
    ax.text(5.0, 3.1, f"c' = {c_prime:.3f}{sig_star(p_c)} (direct)",
            ha="center", fontsize=10, color="#E74C3C", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.2",fc="white",alpha=0.9,ec="#E74C3C"))
    # indirect
    ax.text(5.0, 1.8,
            f"Indirect Effect (a×b) = {indirect:.4f}\n95% CI [{ci_lo:.4f}, {ci_hi:.4f}]\n"
            + ("→ Mediation Supported ✓" if ci_lo*ci_hi>0 else "→ Mediation NOT Supported ✗"),
            ha="center", va="center", fontsize=11, fontweight="bold",
            color="green" if ci_lo*ci_hi>0 else "red",
            bbox=dict(boxstyle="round,pad=0.4",fc="white",alpha=0.95,ec="green" if ci_lo*ci_hi>0 else "red"))
    ax.set_title(title, fontsize=13, fontweight="bold", pad=12)
    plt.tight_layout()
    plt.savefig(fig_path, dpi=180)
    plt.close()

mediation_diagram(
    os.path.join(OUT, "Fig8_Mediation_FLFP.png"),
    "H2 Mediation: GBEI → FLFP → Economic Growth",
    "GBEI\n(IV)", "FLFP\n(Mediator 1)", "Economic\nGrowth (DV)",
    a=b_gbei_flfp, b=b_flfp_eg, c_prime=b_gbei_eg_m2,
    indirect=ie_h2, ci_lo=ci_lo_h2, ci_hi=ci_hi_h2,
    p_a=p_gbei_flfp, p_b=p_flfp_eg, p_c=m3.pvalues["GBEI"]
)
print("  → Fig8_Mediation_FLFP.png saved")

mediation_diagram(
    os.path.join(OUT, "Fig9_Mediation_II.png"),
    "H3 Mediation: GBEI → Income Inequality → Economic Growth",
    "GBEI\n(IV)", "Income\nInequality (M2)", "Economic\nGrowth (DV)",
    a=b_gbei_ii, b=b_ii_eg, c_prime=m5.params["GBEI"],
    indirect=ie_h3, ci_lo=ci_lo_h3, ci_hi=ci_hi_h3,
    p_a=p_gbei_ii, p_b=p_ii_eg, p_c=m5.pvalues["GBEI"]
)
print("  → Fig9_Mediation_II.png saved")

# =============================================================================
# 13.  MODERATION PLOT (H4)
# =============================================================================
print("\n" + "=" * 70)
print(" STEP 13 – MODERATION PLOT")
print("=" * 70)

pee_lo = df["PEE_c"].mean() - df["PEE_c"].std()
pee_hi = df["PEE_c"].mean() + df["PEE_c"].std()

gbei_range = np.linspace(df["GBEI_c"].min(), df["GBEI_c"].max(), 100)
const_coef = m6.params["const"]
gbei_coef  = m6.params["GBEI_c"]
pee_coef   = m6.params["PEE_c"]
int_coef   = m6.params["GBEI_PEE"]

eg_lo = const_coef + gbei_coef*gbei_range + pee_coef*pee_lo + int_coef*gbei_range*pee_lo
eg_hi = const_coef + gbei_coef*gbei_range + pee_coef*pee_hi + int_coef*gbei_range*pee_hi

fig, ax = plt.subplots(figsize=(10, 6))
ax.plot(gbei_range + df["GBEI"].mean(), eg_lo,
        color="#E74C3C", lw=2.5, label="Low PEE (−1 SD)")
ax.plot(gbei_range + df["GBEI"].mean(), eg_hi,
        color="#27AE60", lw=2.5, linestyle="--", label="High PEE (+1 SD)")
ax.fill_between(gbei_range + df["GBEI"].mean(), eg_lo, eg_hi, alpha=0.08, color="grey")
ax.set_xlabel("Gender-Based Educational Inequality (GBEI)", fontsize=12)
ax.set_ylabel("Predicted Economic Growth (EG)", fontsize=12)
ax.set_title("H4 – Moderation Effect of Public Expenditure on Education (PEE)\n"
             f"on GBEI → EG  (β interaction = {b_interact:.4f}, {sig_star(p_interact)})",
             fontweight="bold", fontsize=12)
ax.legend(fontsize=11)
ax.text(0.98, 0.04,
        f"R² = {r2_h4:.3f}\nInteraction β = {b_interact:.4f}\np = {p_interact:.4f}",
        transform=ax.transAxes, ha="right", va="bottom", fontsize=10,
        bbox=dict(boxstyle="round,pad=0.4", fc="white", alpha=0.8, ec="grey"))
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig10_Moderation_PEE.png"))
plt.close()
print("  → Fig10_Moderation_PEE.png saved")

# =============================================================================
# 14.  PREDICTIVE RELEVANCE Q² (Stone-Geisser)
# =============================================================================
print("\n" + "=" * 70)
print(" STEP 14 – PREDICTIVE RELEVANCE Q²")
print("=" * 70)

# blindfolding approximation via cross-validation R²
from sklearn.model_selection import cross_val_score
from sklearn.linear_model import LinearRegression

def q2_blindfold(df, predictors, target):
    X = df[predictors].values
    y = df[target].values
    cv_r2 = cross_val_score(LinearRegression(), X, y, cv=10, scoring="r2")
    # Q² ≈ mean CV R² (Stone-Geisser approximation)
    return round(cv_r2.mean(), 4)

q2_eg = q2_blindfold(df, ["GBEI","FLFP","II","PEE"], "EG")
q2_flfp = q2_blindfold(df, ["GBEI"], "FLFP")
q2_ii   = q2_blindfold(df, ["GBEI"], "II")

q2_df = pd.DataFrame([
    {"Endogenous": "EG",   "Predictors": "GBEI, FLFP, II, PEE", "Q²": q2_eg,   "Adequate (Q²>0)": "Yes" if q2_eg>0 else "No"},
    {"Endogenous": "FLFP", "Predictors": "GBEI",                "Q²": q2_flfp, "Adequate (Q²>0)": "Yes" if q2_flfp>0 else "No"},
    {"Endogenous": "II",   "Predictors": "GBEI",                "Q²": q2_ii,   "Adequate (Q²>0)": "Yes" if q2_ii>0 else "No"},
])
q2_df.to_excel(writer, sheet_name="Predictive_Relevance_Q2", index=False)
print(q2_df.to_string(index=False))
print("  → Q² table saved")

# =============================================================================
# 15.  COMPREHENSIVE SUMMARY DASHBOARD
# =============================================================================
print("\n" + "=" * 70)
print(" STEP 15 – SUMMARY DASHBOARD")
print("=" * 70)

fig = plt.figure(figsize=(20, 12))
fig.patch.set_facecolor("#f8f9fa")
fig.suptitle("Comprehensive Analysis Dashboard\nGender Inequality in Education & Economic Growth (N=400)",
             fontsize=15, fontweight="bold", y=0.98)

gs = fig.add_gridspec(3, 4, hspace=0.5, wspace=0.4)

# Panel 1: α / CR / AVE
ax1 = fig.add_subplot(gs[0, :2])
x_pos = np.arange(len(constructs_list))
width = 0.25
alpha_v = [rel_df.loc[rel_df.Construct==c,"Cronbach's α"].values[0] for c in constructs_list]
cr_v    = [rel_df.loc[rel_df.Construct==c,"Composite Reliability (CR)"].values[0] for c in constructs_list]
ave_v   = [rel_df.loc[rel_df.Construct==c,"AVE"].values[0] for c in constructs_list]
ax1.bar(x_pos - width, alpha_v, width, label="Cronbach's α", color="#2ECC71", edgecolor="k", lw=0.5)
ax1.bar(x_pos,         cr_v,    width, label="CR",            color="#3498DB", edgecolor="k", lw=0.5)
ax1.bar(x_pos + width, ave_v,   width, label="AVE",           color="#E74C3C", edgecolor="k", lw=0.5)
ax1.set_xticks(x_pos)
ax1.set_xticklabels(constructs_list)
ax1.axhline(0.85, color="green", ls="--", lw=1.2)
ax1.axhline(0.50, color="red",   ls=":", lw=1.2)
ax1.set_ylim(0, 1.15)
ax1.set_title("Reliability & Validity (α / CR / AVE)", fontweight="bold")
ax1.legend(fontsize=8)

# Panel 2: Correlation matrix
ax2 = fig.add_subplot(gs[0, 2:])
sns.heatmap(corr_mat, annot=True, fmt=".2f", cmap="coolwarm",
            center=0, ax=ax2, linewidths=0.5, cbar=False)
ax2.set_title("Construct Correlation Matrix", fontweight="bold")

# Panel 3: Path coefficients bar
ax3 = fig.add_subplot(gs[1, :2])
path_labels = ["H1\nGBEI→EG","H2a\nGBEI→FLFP","H2b\nFLFP→EG",
               "H3a\nGBEI→II","H3b\nII→EG","H4\nGBEI×PEE"]
path_betas  = [b_gbei_eg, b_gbei_flfp, b_flfp_eg, b_gbei_ii, b_ii_eg, b_interact]
path_pvals  = [p_gbei_eg, p_gbei_flfp, p_flfp_eg, p_gbei_ii, p_ii_eg, p_interact]
bar_colors  = ["#27AE60" if b>0 else "#E74C3C" for b in path_betas]
bars3 = ax3.bar(path_labels, path_betas, color=bar_colors, edgecolor="k", lw=0.5, alpha=0.8)
ax3.axhline(0, color="black", lw=1.0)
ax3.set_ylabel("Path Coefficient (β)")
ax3.set_title("Structural Path Coefficients", fontweight="bold")
for bar, pv in zip(bars3, path_pvals):
    ax3.text(bar.get_x()+bar.get_width()/2,
             bar.get_height() + (0.01 if bar.get_height()>=0 else -0.03),
             sig_star(pv), ha="center", fontsize=10, fontweight="bold")

# Panel 4: Bootstrap CI plot
ax4 = fig.add_subplot(gs[1, 2:])
effects = ["H2 Indirect\n(FLFP)", "H3 Indirect\n(II)", "H4 Interaction\n(PEE)"]
betas4  = [ie_h2, ie_h3, ie_h4]
ci_los4 = [ci_lo_h2, ci_lo_h3, ci_lo_h4]
ci_his4 = [ci_hi_h2, ci_hi_h3, ci_hi_h4]
colors4 = ["#3498DB","#27AE60","#9B59B6"]
for i,(eff,b,lo,hi,c) in enumerate(zip(effects,betas4,ci_los4,ci_his4,colors4)):
    ax4.plot([i], [b], "o", color=c, markersize=10, zorder=5)
    ax4.plot([i,i], [lo,hi], "-", color=c, lw=2.5, zorder=4)
    ax4.text(i+0.08, b, f"{b:.4f}", va="center", fontsize=9, color=c, fontweight="bold")
ax4.axhline(0, color="red", ls="--", lw=1.5)
ax4.set_xticks(range(len(effects)))
ax4.set_xticklabels(effects, fontsize=9)
ax4.set_ylabel("Effect Size")
ax4.set_title("Bootstrap Effects with 95% CI\n(Red dashed = 0)", fontweight="bold")

# Panel 5: Hypothesis result table
ax5 = fig.add_subplot(gs[2, :])
ax5.axis("off")
table_data = [["Hypothesis","Path","β / IE","p-value","95% CI","Result"]]
for _, row in hyp_df.iterrows():
    table_data.append([
        row["Hypothesis"], row["Statement"],
        str(round(row["β / IE"],4)), str(row["p-value"]),
        row["95% CI"], row["Result"]
    ])
tbl = ax5.table(cellText=table_data[1:], colLabels=table_data[0],
                cellLoc="center", loc="center", bbox=[0,0,1,1])
tbl.auto_set_font_size(False)
tbl.set_fontsize(9)
for (r, c), cell in tbl.get_celld().items():
    if r == 0:
        cell.set_facecolor("#2C3E50")
        cell.set_text_props(color="white", fontweight="bold")
    elif hyp_df.iloc[r-1]["Result"] == "Supported":
        cell.set_facecolor("#D5F5E3")
    else:
        cell.set_facecolor("#FADBD8")
ax5.set_title("Hypothesis Testing Summary", fontweight="bold", pad=10)

plt.savefig(os.path.join(OUT, "Fig11_Summary_Dashboard.png"), dpi=180)
plt.close()
print("  → Fig11_Summary_Dashboard.png saved")

# =============================================================================
# 16.  FULL MODEL REGRESSION SUMMARY
# =============================================================================
print("\n" + "=" * 70)
print(" STEP 16 – FULL REGRESSION SUMMARIES")
print("=" * 70)

for model_name, model_obj in [
    ("EG_full_model", m_full),
    ("FLFP_model",    m2),
    ("II_model",      m4),
    ("Moderation_model", m6),
]:
    summ = model_obj.summary2().tables[1]
    summ.to_excel(writer, sheet_name=f"Regression_{model_name}")
print("  → Full regression summaries saved")

# =============================================================================
# CLOSE & SAVE EXCEL
# =============================================================================
writer.close()
print("\n" + "=" * 70)
print(f" ALL OUTPUTS SAVED TO: {OUT}")
print("=" * 70)
print(f"""
  Survey_Data.csv                     – 400-row raw data
  Full_Analysis_Tables.xlsx           – All tables (15 sheets)

  FIGURES:
  Fig01_Demographic_Analysis.png
  Fig02_Descriptive_Statistics.png
  Fig03_Reliability_Cronbach_Alpha.png
  Fig04_Factor_Loadings_Heatmap.png
  Fig05_Correlation_HTMT.png
  Fig06_Measurement_Model_Indicators.png
  Fig07_SEM_Path_Diagram.png          ← MAIN SEM PATH DIAGRAM
  Fig08_Mediation_FLFP.png            ← H2 Mediation
  Fig09_Mediation_II.png              ← H3 Mediation
  Fig10_Moderation_PEE.png            ← H4 Moderation
  Fig11_Summary_Dashboard.png         ← Comprehensive Dashboard
""")
