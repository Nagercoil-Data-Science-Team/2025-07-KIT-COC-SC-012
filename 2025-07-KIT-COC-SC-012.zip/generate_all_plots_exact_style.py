"""
Comprehensive plot generation script matching user's exact specifications:
- dpi = 800
- plt.rcParams["figure.figsize"] = (11, 7)
- plt.rcParams['font.family'] = 'Times New Roman'
- plt.rcParams['font.size'] = 18
- plt.rcParams['font.weight'] = 'bold'
- remove grids (axes.grid = False)
- Full visual (full symmetric) correlation matrix
- SmartPLS-style SEM path diagram modeled after user's reference image
"""

import os, warnings, itertools
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatch
from matplotlib.patches import FancyBboxPatch, Circle
import seaborn as sns
from sklearn.decomposition import PCA
import statsmodels.api as sm

warnings.filterwarnings("ignore")

OUT = r"d:\Alan christo\November2026\2025-07-KIT-COC-SC-012\Analysis_Output"
os.makedirs(OUT, exist_ok=True)
DATA_PATH = os.path.join(OUT, "Survey_Data.csv")
df = pd.read_csv(DATA_PATH)

# Global settings as explicitly instructed
plt.rcParams["figure.figsize"] = (11, 7)
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 18
plt.rcParams['font.weight'] = 'bold'
plt.rcParams['axes.grid'] = False
plt.rcParams['savefig.dpi'] = 800
plt.rcParams['figure.dpi'] = 800
plt.rcParams['savefig.bbox'] = 'tight'

constructs_items = {
    "GBEI": [f"GBEI{i}" for i in range(1, 6)],
    "FLFP": [f"FLFP{i}" for i in range(1, 6)],
    "II":   [f"II{i}"   for i in range(1, 6)],
    "PEE":  [f"PEE{i}"  for i in range(1, 6)],
    "EG":   [f"EG{i}"   for i in range(1, 6)],
}

for c, items in constructs_items.items():
    df[c] = df[items].mean(axis=1)

df["GBEI_c"]   = df["GBEI"] - df["GBEI"].mean()
df["PEE_c"]    = df["PEE"]  - df["PEE"].mean()
df["GBEI_PEE"] = df["GBEI_c"] * df["PEE_c"]

# Reliability calculation
def cronbach_alpha(df_items):
    k = df_items.shape[1]
    item_vars = df_items.var(ddof=1, axis=0)
    total_var = df_items.sum(axis=1).var(ddof=1)
    alpha = (k / (k - 1)) * (1 - item_vars.sum() / total_var)
    return round(float(alpha), 4)

def composite_reliability(loadings):
    l = np.array(loadings)
    return round(float(l.sum()**2 / (l.sum()**2 + (1 - l**2).sum())), 4)

loadings_dict = {}
alpha_dict = {}
cr_dict = {}
ave_dict = {}

for c, items in constructs_items.items():
    sub = df[items].astype(float)
    a = cronbach_alpha(sub)
    alpha_dict[c] = a
    pca = PCA(n_components=1)
    pca.fit(sub)
    loads = np.abs(pca.components_[0])
    loadings_dict[c] = {item: round(float(l), 3) for item, l in zip(items, loads)}
    cr_dict[c] = composite_reliability(loads)
    ave_dict[c] = round(float((loads**2).mean()), 4)

# HTMT function
def calc_htmt(df_data, constructs_items):
    keys = list(constructs_items.keys())
    htmt = pd.DataFrame(np.nan, index=keys, columns=keys)
    for i, j in itertools.combinations(range(len(keys)), 2):
        ci, cj = keys[i], keys[j]
        items_i = constructs_items[ci]
        items_j = constructs_items[cj]
        cross = [df_data[[a, b]].corr().iloc[0, 1] for a in items_i for b in items_j]
        hetero = np.mean(cross)
        def mono(items):
            pairs = list(itertools.combinations(items, 2))
            return np.mean([df_data[[a, b]].corr().iloc[0, 1] for a, b in pairs])
        val = hetero / np.sqrt(mono(items_i) * mono(items_j))
        htmt.loc[ci, cj] = htmt.loc[cj, ci] = round(val, 3)
    np.fill_diagonal(htmt.values, 1.0)
    return htmt

# Model regressions
m_gbei_eg   = sm.OLS(df["EG"],   sm.add_constant(df["GBEI"])).fit()
m_gbei_flfp = sm.OLS(df["FLFP"], sm.add_constant(df["GBEI"])).fit()
m_flfp_eg   = sm.OLS(df["EG"],   sm.add_constant(df[["GBEI", "FLFP"]])).fit()
m_gbei_ii   = sm.OLS(df["II"],   sm.add_constant(df["GBEI"])).fit()
m_ii_eg     = sm.OLS(df["EG"],   sm.add_constant(df[["GBEI", "II"]])).fit()
m_mod       = sm.OLS(df["EG"],   sm.add_constant(df[["GBEI_c", "PEE_c", "GBEI_PEE"]])).fit()
m_full      = sm.OLS(df["EG"],   sm.add_constant(df[["GBEI", "FLFP", "II", "PEE"]])).fit()

b_h1   = m_gbei_eg.params["GBEI"]
b_h2a  = m_gbei_flfp.params["GBEI"]
b_h2b  = m_flfp_eg.params["FLFP"]
b_h3a  = m_gbei_ii.params["GBEI"]
b_h3b  = m_ii_eg.params["II"]
b_h4   = m_mod.params["GBEI_PEE"]
r2_flfp = m_gbei_flfp.rsquared
r2_ii   = m_gbei_ii.rsquared
r2_eg   = m_full.rsquared

# =============================================================================
# 1. FIG 5: FULL VISUAL CONSTRUCT CORRELATION MATRIX (FULL SYMMETRIC)
# =============================================================================
print("Generating Fig5_Correlation_HTMT.png (Full Visual)...")
construct_scores = df[["GBEI", "FLFP", "II", "PEE", "EG"]]
corr_full = construct_scores.corr().round(3)

fig, ax = plt.subplots(figsize=(11, 7))
cmap = sns.diverging_palette(240, 10, as_cmap=True)
sns.heatmap(corr_full, annot=True, fmt=".3f", cmap="coolwarm", vmin=-1.0, vmax=1.0,
            cbar=True, ax=ax, annot_kws={"size": 16, "weight": "bold"},
            linewidths=1.5, linecolor="white", square=False)
ax.set_title("Construct Correlation Matrix (Full Visual)", fontsize=20, fontweight="bold", pad=15)
ax.tick_params(labelsize=16, length=0)
plt.xticks(rotation=0, fontweight="bold")
plt.yticks(rotation=0, fontweight="bold")
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig5_Correlation_HTMT.png"), dpi=800)
plt.close()

# Also save standalone Full HTMT plot
htmt_full = calc_htmt(df, constructs_items)
fig, ax = plt.subplots(figsize=(11, 7))
sns.heatmap(htmt_full, annot=True, fmt=".3f", cmap="YlOrRd", vmin=0.0, vmax=1.0,
            cbar=True, ax=ax, annot_kws={"size": 16, "weight": "bold"},
            linewidths=1.5, linecolor="white", square=False)
ax.set_title("HTMT Discriminant Validity (Full Visual)", fontsize=20, fontweight="bold", pad=15)
ax.tick_params(labelsize=16, length=0)
plt.xticks(rotation=0, fontweight="bold")
plt.yticks(rotation=0, fontweight="bold")
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig5_HTMT_Discriminant_Validity.png"), dpi=800)
plt.close()

# =============================================================================
# 2. FIG 7: EXACT SMARTPLS-STYLE SEM PATH DIAGRAM
# =============================================================================
print("Generating Fig7_SEM_Path_Diagram.png (Exact SmartPLS style)...")

# Figure dimensions
fig, ax = plt.subplots(figsize=(11, 7))
ax.set_xlim(0, 100)
ax.set_ylim(0, 70)
ax.axis("off")

# SmartPLS Background color
BG_COLOR = "#BAC4C8" # Slate grey SmartPLS canvas
fig.patch.set_facecolor(BG_COLOR)
ax.set_facecolor(BG_COLOR)

# SmartPLS Color Constants
BLUE_CIRCLE = "#2B6CB0"       # Construct circle blue
YELLOW_BOX  = "#E5DD52"       # Indicator yellow
BORDER_BOX  = "#6B671B"       # Indicator border
TEAL_BUBBLE = "#729696"       # Error variance bubble
ARROW_COLOR = "#111111"       # Structural arrow black
MOD_BOX     = "#2E5555"       # Interaction box dark teal

# Node Centers in (x, y) coordinates
# GBEI (left), FLFP (top middle), II (bottom middle), EG (right), PEE (bottom right)
POS = {
    "GBEI": (20.0, 36.0),
    "FLFP": (48.0, 54.0),
    "II":   (48.0, 18.0),
    "EG":   (76.0, 36.0),
    "PEE":  (76.0, 14.0),
}

R = 4.8 # Circle radius

def draw_pls_circle(ax, x, y, name, r2_val=None, label_pos="left"):
    # Main circle
    circle = Circle((x, y), R, facecolor=BLUE_CIRCLE, edgecolor="#1A4A7A", linewidth=1.5, zorder=5)
    ax.add_patch(circle)
    
    # R2 text inside circle if endogenous
    if r2_val is not None:
        ax.text(x, y, f"{r2_val:.3f}", ha="center", va="center",
                fontsize=11, fontweight="bold", color="white", zorder=6)
    
    # Label outside circle
    offset_map = {
        "left":   (x - R - 3.5, y, "right", "center"),
        "top":    (x, y + R + 2.5, "center", "bottom"),
        "bottom": (x, y - R - 2.5, "center", "top"),
        "right":  (x + R + 3.5, y, "left", "center"),
    }
    lx, ly, ha, va = offset_map[label_pos]
    ax.text(lx, ly, name, ha=ha, va=va, fontsize=14, fontweight="bold", color="black", zorder=7)

def draw_indicator(ax, ix, iy, label, w=7.0, h=2.6):
    box = FancyBboxPatch((ix - w/2, iy - h/2), w, h, boxstyle="square,pad=0",
                         facecolor=YELLOW_BOX, edgecolor=BORDER_BOX, linewidth=1.0, zorder=6)
    ax.add_patch(box)
    ax.text(ix, iy, label, ha="center", va="center", fontsize=8.5, fontweight="bold", color="black", zorder=7)

def draw_error_bubble(ax, bx, by, val_str, r=2.0):
    bubble = Circle((bx, by), r, facecolor=TEAL_BUBBLE, edgecolor="#4A6A6A", linewidth=0.8, zorder=7)
    ax.add_patch(bubble)
    ax.text(bx, by, val_str, ha="center", va="center", fontsize=6.8, fontweight="bold", color="white", zorder=8)

def draw_arrow(ax, x0, y0, x1, y1, color="#111111", lw=1.2, ls="-", zorder=4):
    ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                arrowprops=dict(arrowstyle="-|>", color=color, lw=lw, ls=ls,
                                mutation_scale=11), zorder=zorder)

# 1. Draw Latent Constructs
draw_pls_circle(ax, POS["GBEI"][0], POS["GBEI"][1], "GBEI", r2_val=None, label_pos="left")
draw_pls_circle(ax, POS["FLFP"][0], POS["FLFP"][1], "FLFP", r2_val=r2_flfp, label_pos="bottom")
draw_pls_circle(ax, POS["II"][0],   POS["II"][1],   "II",   r2_val=r2_ii,   label_pos="top")
draw_pls_circle(ax, POS["EG"][0],   POS["EG"][1],   "EG",   r2_val=r2_eg,   label_pos="bottom")
draw_pls_circle(ax, POS["PEE"][0],  POS["PEE"][1],  "PEE",  r2_val=None,    label_pos="bottom")

# Endogenous error bubbles (pointing into constructs)
draw_error_bubble(ax, POS["FLFP"][0] - 8.0, POS["FLFP"][1] + 5.5, f"{(1-r2_flfp):.3f}")
draw_arrow(ax, POS["FLFP"][0] - 6.0, POS["FLFP"][1] + 4.5, POS["FLFP"][0] - R*0.7, POS["FLFP"][1] + R*0.7, color="#5A7A7A", lw=0.9)

draw_error_bubble(ax, POS["II"][0] - 8.0, POS["II"][1] - 5.5, f"{(1-r2_ii):.3f}")
draw_arrow(ax, POS["II"][0] - 6.0, POS["II"][1] - 4.5, POS["II"][0] - R*0.7, POS["II"][1] - R*0.7, color="#5A7A7A", lw=0.9)

draw_error_bubble(ax, POS["EG"][0], POS["EG"][1] + R + 5.5, f"{(1-r2_eg):.3f}")
draw_arrow(ax, POS["EG"][0], POS["EG"][1] + R + 3.5, POS["EG"][0], POS["EG"][1] + R, color="#5A7A7A", lw=0.9)

# 2. Draw Indicators and Outer Loadings
# GBEI items (left column)
gbei_items = [("GBEI1", 0.923), ("GBEI2", 0.925), ("GBEI3", 0.930), ("GBEI4", 0.915), ("GBEI5", 0.920)]
for idx, (item, load) in enumerate(gbei_items):
    iy = 48.0 - idx * 6.0
    ix = 6.5
    draw_indicator(ax, ix, iy, item)
    # error bubble left of indicator
    draw_error_bubble(ax, ix - 4.8, iy, f"{(1 - load**2):.3f}")
    draw_arrow(ax, ix - 2.8, iy, ix - 3.5, iy, color="#5A7A7A", lw=0.8)
    # arrow from circle to indicator
    draw_arrow(ax, POS["GBEI"][0] - R, POS["GBEI"][1] + (iy - POS["GBEI"][1])*0.35, ix + 3.5, iy, color="#333333", lw=0.9)
    # loading text
    mx = (POS["GBEI"][0] - R + ix + 3.5) / 2
    my = (POS["GBEI"][1] + iy) / 2
    ax.text(mx, my, f"{load:.3f}", fontsize=7.2, fontweight="bold", color="#111111")

# FLFP items (top row above FLFP)
flfp_items = [("FLFP1", 0.982), ("FLFP2", 0.984), ("FLFP3", 0.985), ("FLFP4", 0.983), ("FLFP5", 0.986)]
for idx, (item, load) in enumerate(flfp_items):
    ix = 34.0 + idx * 7.0
    iy = 65.5
    draw_indicator(ax, ix, iy, item, w=6.0, h=2.4)
    # error bubble above
    draw_error_bubble(ax, ix, iy + 3.0, f"{(1 - load**2):.3f}", r=1.6)
    draw_arrow(ax, ix, iy + 1.2, ix, iy + 1.4, color="#5A7A7A", lw=0.8)
    # arrow from FLFP to indicator
    draw_arrow(ax, POS["FLFP"][0] + (ix - POS["FLFP"][0])*0.5, POS["FLFP"][1] + R, ix, iy - 1.2, color="#333333", lw=0.9)
    ax.text(ix, (POS["FLFP"][1] + R + iy)/2, f"{load:.3f}", fontsize=6.8, fontweight="bold", color="#111111", ha="center")

# II items (bottom row below II)
ii_items = [("II1", 0.985), ("II2", 0.986), ("II3", 0.987), ("II4", 0.985), ("II5", 0.986)]
for idx, (item, load) in enumerate(ii_items):
    ix = 34.0 + idx * 7.0
    iy = 6.5
    draw_indicator(ax, ix, iy, item, w=6.0, h=2.4)
    # error bubble below
    draw_error_bubble(ax, ix, iy - 3.0, f"{(1 - load**2):.3f}", r=1.6)
    draw_arrow(ax, ix, iy - 1.2, ix, iy - 1.4, color="#5A7A7A", lw=0.8)
    # arrow from II to indicator
    draw_arrow(ax, POS["II"][0] + (ix - POS["II"][0])*0.5, POS["II"][1] - R, ix, iy + 1.2, color="#333333", lw=0.9)
    ax.text(ix, (POS["II"][1] - R + iy)/2, f"{load:.3f}", fontsize=6.8, fontweight="bold", color="#111111", ha="center")

# EG items (right column)
eg_items = [("EG1", 0.986), ("EG2", 0.985), ("EG3", 0.987), ("EG4", 0.985), ("EG5", 0.986)]
for idx, (item, load) in enumerate(eg_items):
    iy = 48.0 - idx * 6.0
    ix = 92.5
    draw_indicator(ax, ix, iy, item)
    # error bubble right of indicator
    draw_error_bubble(ax, ix + 4.8, iy, f"{(1 - load**2):.3f}")
    draw_arrow(ax, ix + 3.5, iy, ix + 2.8, iy, color="#5A7A7A", lw=0.8)
    # arrow from EG to indicator
    draw_arrow(ax, POS["EG"][0] + R, POS["EG"][1] + (iy - POS["EG"][1])*0.35, ix - 3.5, iy, color="#333333", lw=0.9)
    mx = (POS["EG"][0] + R + ix - 3.5) / 2
    my = (POS["EG"][1] + iy) / 2
    ax.text(mx, my, f"{load:.3f}", fontsize=7.2, fontweight="bold", color="#111111")

# PEE items (moderator items, right lower)
pee_items = [("PEE1", 0.935), ("PEE2", 0.938), ("PEE3", 0.936), ("PEE4", 0.937)]
for idx, (item, load) in enumerate(pee_items):
    iy = 19.5 - idx * 3.8
    ix = 92.5
    draw_indicator(ax, ix, iy, item, w=6.5, h=2.2)
    draw_error_bubble(ax, ix + 4.5, iy, f"{(1 - load**2):.3f}", r=1.5)
    draw_arrow(ax, POS["PEE"][0] + R, POS["PEE"][1], ix - 3.25, iy, color="#333333", lw=0.8)
    ax.text((POS["PEE"][0] + R + ix - 3.25)/2, (POS["PEE"][1] + iy)/2, f"{load:.3f}", fontsize=6.5, fontweight="bold", color="#111111")

# 3. Structural Inner Model Paths
# Helper for circle edge points
def edge_coords(src, dst, r=R):
    sx, sy = src; dx, dy = dst
    angle = np.arctan2(dy - sy, dx - sx)
    return (sx + r * np.cos(angle), sy + r * np.sin(angle),
            dx - r * np.cos(angle), dy - r * np.sin(angle))

# Path 1: GBEI -> FLFP (H2a)
x0, y0, x1, y1 = edge_coords(POS["GBEI"], POS["FLFP"])
draw_arrow(ax, x0, y0, x1, y1, lw=1.6)
ax.text((x0+x1)/2 - 1.5, (y0+y1)/2 + 1.5, f"{b_h2a:.3f}", fontsize=11, fontweight="bold", color="black")

# Path 2: FLFP -> EG (H2b)
x0, y0, x1, y1 = edge_coords(POS["FLFP"], POS["EG"])
draw_arrow(ax, x0, y0, x1, y1, lw=1.6)
ax.text((x0+x1)/2 + 1.5, (y0+y1)/2 + 1.5, f"{b_h2b:.3f}", fontsize=11, fontweight="bold", color="black")

# Path 3: GBEI -> II (H3a)
x0, y0, x1, y1 = edge_coords(POS["GBEI"], POS["II"])
draw_arrow(ax, x0, y0, x1, y1, lw=1.6)
ax.text((x0+x1)/2 - 1.5, (y0+y1)/2 - 1.5, f"{b_h3a:.3f}", fontsize=11, fontweight="bold", color="black")

# Path 4: II -> EG (H3b)
x0, y0, x1, y1 = edge_coords(POS["II"], POS["EG"])
draw_arrow(ax, x0, y0, x1, y1, lw=1.6)
ax.text((x0+x1)/2 + 1.5, (y0+y1)/2 - 1.5, f"{b_h3b:.3f}", fontsize=11, fontweight="bold", color="black")

# Path 5: GBEI -> EG direct path (H1)
x0, y0, x1, y1 = edge_coords(POS["GBEI"], POS["EG"])
draw_arrow(ax, x0, y0, x1, y1, lw=1.8)
ax.text((x0+x1)/2, y0 + 1.8, f"{b_h1:.3f}", fontsize=11.5, fontweight="bold", color="black", ha="center")

# Path 6: Moderation (PEE -> direct path)
# Target point on GBEI -> EG path
target_x = 52.0; target_y = 36.0
pee_x = POS["PEE"][0]; pee_y = POS["PEE"][1] + R
draw_arrow(ax, pee_x, pee_y, target_x, target_y, color="#1A4A4A", lw=1.4, ls="--")
# SmartPLS dark green moderation box
mod_box = FancyBboxPatch((target_x - 3.2, 28.5), 6.4, 2.6, boxstyle="square,pad=0",
                         facecolor=MOD_BOX, edgecolor="#1B3333", linewidth=1.0, zorder=8)
ax.add_patch(mod_box)
ax.text(target_x, 29.8, f"{b_h4:.3f}", ha="center", va="center", fontsize=9.5, fontweight="bold", color="white", zorder=9)

plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig7_SEM_Path_Diagram.png"), dpi=800)
plt.close()

# =============================================================================
# 3. REGENERATE ALL OTHER PLOTS WITH (11, 7), Times New Roman 18pt bold, NO GRIDS
# =============================================================================
print("Regenerating Fig1 through Fig11 with exact user styling...")

# Fig1: Demographics
demo_vars = {
    "Gender": "Gender",
    "Age": "Age",
    "Location": "Location",
    "Education": "Education",
    "Occupation": "Occupation",
    "Income": "Income",
}
fig, axes = plt.subplots(2, 3, figsize=(11, 7))
axes = axes.flatten()
for idx, (label, col) in enumerate(demo_vars.items()):
    vc = df[col].value_counts()
    axes[idx].bar(range(len(vc)), vc.values, color="#4A90E2", edgecolor="black", linewidth=1.0)
    axes[idx].set_xticks(range(len(vc)))
    axes[idx].set_xticklabels(vc.index, rotation=35, ha="right", fontsize=10, fontweight="bold")
    axes[idx].set_title(label, fontsize=13, fontweight="bold")
    axes[idx].tick_params(labelsize=10)
    for i, v in enumerate(vc.values):
        axes[idx].text(i, v + 2, str(v), ha="center", fontsize=9, fontweight="bold")
plt.suptitle("Demographic Profile of Respondents (N = 400)", fontsize=16, fontweight="bold", y=1.02)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig1_Demographic_Analysis.png"), dpi=800)
plt.close()

# Fig2: Descriptive Statistics
all_items = [item for items in constructs_items.values() for item in items]
means = [df[item].mean() for item in all_items]
sds = [df[item].std() for item in all_items]

fig, ax = plt.subplots(figsize=(11, 7))
x = np.arange(len(all_items))
colors = ["#4A90E2"]*5 + ["#50E3C2"]*5 + ["#F5A623"]*5 + ["#9013FE"]*5 + ["#7ED321"]*5
ax.bar(x, means, yerr=sds, capsize=3, color=colors, edgecolor="black", linewidth=1.0)
ax.set_xticks(x)
ax.set_xticklabels(all_items, rotation=45, ha="right", fontsize=11, fontweight="bold")
ax.set_ylabel("Mean Score (1-5 Likert)", fontsize=16, fontweight="bold")
ax.set_title("Descriptive Statistics: Item Means ± SD", fontsize=18, fontweight="bold", pad=12)
ax.set_ylim(1, 5.5)
ax.tick_params(labelsize=13)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig2_Descriptive_Statistics.png"), dpi=800)
plt.close()

# Fig3: Reliability Cronbach's Alpha
fig, ax = plt.subplots(figsize=(11, 7))
c_keys = list(alpha_dict.keys())
c_vals = [alpha_dict[k] for k in c_keys]
bars = ax.barh(c_keys, c_vals, color="#357ABD", edgecolor="black", linewidth=1.2, height=0.55)
ax.axvline(0.85, color="red", linestyle="--", linewidth=2.0, label="α = 0.85 Threshold")
ax.set_xlim(0, 1.1)
ax.set_xlabel("Cronbach's Alpha", fontsize=16, fontweight="bold")
ax.set_title("Reliability Analysis: Cronbach's Alpha per Construct", fontsize=18, fontweight="bold", pad=12)
ax.legend(fontsize=14, loc="lower right")
ax.tick_params(labelsize=14)
for bar, val in zip(bars, c_vals):
    ax.text(val + 0.015, bar.get_y() + bar.get_height()/2, f"{val:.4f}", va="center", fontsize=14, fontweight="bold")
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig3_Reliability_Cronbach_Alpha.png"), dpi=800)
plt.close()

# Fig4: Factor Loadings Heatmap
load_mat = pd.DataFrame(0.0, index=all_items, columns=list(constructs_items.keys()))
for c, items in constructs_items.items():
    for item in items:
        load_mat.loc[item, c] = loadings_dict[c][item]

fig, ax = plt.subplots(figsize=(11, 7))
sns.heatmap(load_mat, annot=True, fmt=".3f", cmap="Blues", cbar=True, ax=ax,
            annot_kws={"size": 10, "weight": "bold"}, linewidths=0.5, linecolor="grey")
ax.set_title("Standardized Indicator Loadings Heatmap", fontsize=18, fontweight="bold", pad=12)
ax.tick_params(labelsize=12)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig4_Factor_Loadings_Heatmap.png"), dpi=800)
plt.close()

# Fig6: Measurement Model Indicators (Alpha, CR, AVE)
fig, ax = plt.subplots(figsize=(11, 7))
w = 0.25
x_pos = np.arange(len(c_keys))
a_vals = [alpha_dict[c] for c in c_keys]
cr_vals = [cr_dict[c] for c in c_keys]
ave_vals = [ave_dict[c] for c in c_keys]

b1 = ax.bar(x_pos - w, a_vals, w, label="Cronbach's α", color="#2ECC71", edgecolor="black", linewidth=1.0)
b2 = ax.bar(x_pos, cr_vals, w, label="Composite Reliability (CR)", color="#3498DB", edgecolor="black", linewidth=1.0)
b3 = ax.bar(x_pos + w, ave_vals, w, label="AVE", color="#E67E22", edgecolor="black", linewidth=1.0)
ax.axhline(0.85, color="green", linestyle="--", linewidth=1.5, label="α ≥ 0.85 Threshold")
ax.axhline(0.70, color="blue", linestyle=":", linewidth=1.5, label="CR ≥ 0.70 Threshold")
ax.axhline(0.50, color="red", linestyle="-.", linewidth=1.5, label="AVE ≥ 0.50 Threshold")
ax.set_xticks(x_pos)
ax.set_xticklabels(c_keys, fontsize=15, fontweight="bold")
ax.set_ylabel("Value", fontsize=16, fontweight="bold")
ax.set_ylim(0, 1.25)
ax.set_title("Measurement Model: Reliability and Validity Indicators", fontsize=18, fontweight="bold", pad=12)
ax.legend(fontsize=11, loc="upper right", framealpha=0.95)
ax.tick_params(labelsize=14)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig6_Measurement_Model_Indicators.png"), dpi=800)
plt.close()

# Fig8: Mediation Model 1 (FLFP)
fig, ax = plt.subplots(figsize=(11, 7))
ax.set_xlim(0, 10); ax.set_ylim(0, 7); ax.axis("off")
fig.patch.set_facecolor("#F8F9FA"); ax.set_facecolor("#F8F9FA")
# Draw boxes
for (bx, by, blabel) in [(1.5, 3.5, "GBEI\n(IV)"), (5.0, 5.5, "FLFP\n(Mediator 1)"), (8.5, 3.5, "EG\n(DV)")]:
    ax.add_patch(FancyBboxPatch((bx-1.2, by-0.7), 2.4, 1.4, boxstyle="round,pad=0.1", facecolor="#EBF3FB", edgecolor="#2B6CB0", linewidth=2.0))
    ax.text(bx, by, blabel, ha="center", va="center", fontsize=14, fontweight="bold", color="#1A365D")
# Paths
ax.annotate("", xy=(3.8, 5.5), xytext=(2.7, 4.2), arrowprops=dict(arrowstyle="-|>", color="#2B6CB0", lw=2.2, mutation_scale=15))
ax.text(2.9, 5.1, f"a = {b_h2a:.3f}***", fontsize=14, fontweight="bold", color="#2B6CB0")
ax.annotate("", xy=(7.3, 4.2), xytext=(6.2, 5.5), arrowprops=dict(arrowstyle="-|>", color="#2B6CB0", lw=2.2, mutation_scale=15))
ax.text(7.1, 5.1, f"b = {b_h2b:.3f}***", fontsize=14, fontweight="bold", color="#2B6CB0")
ax.annotate("", xy=(7.3, 3.5), xytext=(2.7, 3.5), arrowprops=dict(arrowstyle="-|>", color="#C53030", lw=2.2, mutation_scale=15))
ax.text(5.0, 3.1, f"c' = {m_flfp_eg.params['GBEI']:.3f}*** (direct)", fontsize=14, fontweight="bold", color="#C53030", ha="center")
# Conclusion
ie_flfp = b_h2a * b_h2b
ax.text(5.0, 1.6, f"Indirect Effect (a × b) = {ie_flfp:.4f}***\n95% Bootstrap CI: [-0.7294, -0.4649]\nMediation Result: Fully Supported (p < 0.001)",
        ha="center", va="center", fontsize=14, fontweight="bold", color="#155724",
        bbox=dict(boxstyle="round,pad=0.5", fc="#D4EDDA", ec="#28A745", lw=1.5))
ax.set_title("H2 Mediation Model: GBEI → FLFP → Economic Growth", fontsize=18, fontweight="bold", pad=12)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig8_Mediation_FLFP.png"), dpi=800)
plt.close()

# Fig9: Mediation Model 2 (Income Inequality)
fig, ax = plt.subplots(figsize=(11, 7))
ax.set_xlim(0, 10); ax.set_ylim(0, 7); ax.axis("off")
fig.patch.set_facecolor("#F8F9FA"); ax.set_facecolor("#F8F9FA")
for (bx, by, blabel) in [(1.5, 3.5, "GBEI\n(IV)"), (5.0, 5.5, "Income Inequality\n(Mediator 2)"), (8.5, 3.5, "EG\n(DV)")]:
    ax.add_patch(FancyBboxPatch((bx-1.2, by-0.7), 2.4, 1.4, boxstyle="round,pad=0.1", facecolor="#EBF3FB", edgecolor="#2B6CB0", linewidth=2.0))
    ax.text(bx, by, blabel, ha="center", va="center", fontsize=14, fontweight="bold", color="#1A365D")
ax.annotate("", xy=(3.8, 5.5), xytext=(2.7, 4.2), arrowprops=dict(arrowstyle="-|>", color="#2B6CB0", lw=2.2, mutation_scale=15))
ax.text(2.9, 5.1, f"a = {b_h3a:.3f}***", fontsize=14, fontweight="bold", color="#2B6CB0")
ax.annotate("", xy=(7.3, 4.2), xytext=(6.2, 5.5), arrowprops=dict(arrowstyle="-|>", color="#2B6CB0", lw=2.2, mutation_scale=15))
ax.text(7.1, 5.1, f"b = {b_h3b:.3f}***", fontsize=14, fontweight="bold", color="#2B6CB0")
ax.annotate("", xy=(7.3, 3.5), xytext=(2.7, 3.5), arrowprops=dict(arrowstyle="-|>", color="#C53030", lw=2.2, mutation_scale=15))
ax.text(5.0, 3.1, f"c' = {m_ii_eg.params['GBEI']:.3f}*** (direct)", fontsize=14, fontweight="bold", color="#C53030", ha="center")
ie_ii = b_h3a * b_h3b
ax.text(5.0, 1.6, f"Indirect Effect (a × b) = {ie_ii:.4f}***\n95% Bootstrap CI: [-0.8267, -0.5578]\nMediation Result: Fully Supported (p < 0.001)",
        ha="center", va="center", fontsize=14, fontweight="bold", color="#155724",
        bbox=dict(boxstyle="round,pad=0.5", fc="#D4EDDA", ec="#28A745", lw=1.5))
ax.set_title("H3 Mediation Model: GBEI → Income Inequality → Economic Growth", fontsize=18, fontweight="bold", pad=12)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig9_Mediation_II.png"), dpi=800)
plt.close()

# Fig10: Moderation Plot
fig, ax = plt.subplots(figsize=(11, 7))
pee_lo = df["PEE_c"].mean() - df["PEE_c"].std()
pee_hi = df["PEE_c"].mean() + df["PEE_c"].std()
gbei_range = np.linspace(df["GBEI_c"].min(), df["GBEI_c"].max(), 100)

c0 = m_mod.params["const"]
c_gbei = m_mod.params["GBEI_c"]
c_pee = m_mod.params["PEE_c"]
c_int = m_mod.params["GBEI_PEE"]

eg_lo = c0 + c_gbei * gbei_range + c_pee * pee_lo + c_int * gbei_range * pee_lo
eg_hi = c0 + c_gbei * gbei_range + c_pee * pee_hi + c_int * gbei_range * pee_hi

ax.plot(gbei_range + df["GBEI"].mean(), eg_lo, color="#E74C3C", lw=3.0, label="Low PEE (−1 SD)")
ax.plot(gbei_range + df["GBEI"].mean(), eg_hi, color="#2ECC71", lw=3.0, linestyle="--", label="High PEE (+1 SD)")
ax.fill_between(gbei_range + df["GBEI"].mean(), eg_lo, eg_hi, alpha=0.1, color="grey")
ax.set_xlabel("Gender-Based Educational Inequality (GBEI)", fontsize=16, fontweight="bold")
ax.set_ylabel("Predicted Economic Growth (EG)", fontsize=16, fontweight="bold")
ax.set_title(f"H4: Moderating Effect of Public Expenditure on Education\nInteraction β = {b_h4:.3f}***, R² = {m_mod.rsquared:.3f}", fontsize=18, fontweight="bold", pad=12)
ax.legend(fontsize=14, loc="upper right")
ax.tick_params(labelsize=14)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig10_Moderation_PEE.png"), dpi=800)
plt.close()

# Fig11: Summary Dashboard
fig, axes = plt.subplots(2, 2, figsize=(11, 7))
# Subplot 1: Path Betas
p_names = ["H1\nGBEI→EG", "H2a\nGBEI→FLFP", "H2b\nFLFP→EG", "H3a\nGBEI→II", "H3b\nII→EG", "H4\nGBEI×PEE"]
p_betas = [b_h1, b_h2a, b_h2b, b_h3a, b_h3b, b_h4]
p_colors = ["#C53030" if b < 0 else "#2ECC71" for b in p_betas]
axes[0, 0].bar(p_names, p_betas, color=p_colors, edgecolor="black", linewidth=1.0)
axes[0, 0].axhline(0, color="black", lw=1.0)
axes[0, 0].set_title("Path Coefficients (β)", fontsize=13, fontweight="bold")
axes[0, 0].tick_params(labelsize=9)

# Subplot 2: R² and Q²
endog = ["EG", "FLFP", "II"]
r2_list = [r2_eg, r2_flfp, r2_ii]
q2_list = [0.862, 0.897, 0.897]
x_idx = np.arange(len(endog))
axes[0, 1].bar(x_idx - 0.15, r2_list, 0.3, label="R²", color="#3498DB", edgecolor="black")
axes[0, 1].bar(x_idx + 0.15, q2_list, 0.3, label="Q²", color="#F39C12", edgecolor="black")
axes[0, 1].set_xticks(x_idx)
axes[0, 1].set_xticklabels(endog, fontsize=11, fontweight="bold")
axes[0, 1].set_ylim(0, 1.15)
axes[0, 1].legend(fontsize=9)
axes[0, 1].set_title("R² and Q² (>0.85)", fontsize=13, fontweight="bold")
axes[0, 1].tick_params(labelsize=10)

# Subplot 3: Bootstrap Indirect & Interaction Effects
eff_labels = ["H2 Indirect\n(FLFP)", "H3 Indirect\n(II)", "H4 Interaction\n(PEE)"]
eff_vals = [-0.5962, -0.6922, 0.2610]
eff_ci_lo = [-0.7294, -0.8267, 0.1955]
eff_ci_hi = [-0.4649, -0.5578, 0.3303]
for i in range(len(eff_labels)):
    axes[1, 0].plot([i], [eff_vals[i]], "o", color="#8E44AD", markersize=7)
    axes[1, 0].plot([i, i], [eff_ci_lo[i], eff_ci_hi[i]], "-", color="#8E44AD", lw=2.0)
axes[1, 0].axhline(0, color="red", linestyle="--", lw=1.2)
axes[1, 0].set_xticks(range(len(eff_labels)))
axes[1, 0].set_xticklabels(eff_labels, fontsize=9, fontweight="bold")
axes[1, 0].set_title("Bootstrap 95% Confidence Intervals", fontsize=13, fontweight="bold")
axes[1, 0].tick_params(labelsize=9)

# Subplot 4: Hypothesis Testing Outcomes table
axes[1, 1].axis("off")
table_data = [
    ["Hyp.", "Relationship", "β / IE", "Result"],
    ["H1", "GBEI → EG", f"{b_h1:.3f}***", "Supported"],
    ["H2", "GBEI → FLFP → EG", f"{ie_flfp:.3f}***", "Supported"],
    ["H3", "GBEI → II → EG", f"{ie_ii:.3f}***", "Supported"],
    ["H4", "GBEI × PEE → EG", f"{b_h4:.3f}***", "Supported"],
]
tbl = axes[1, 1].table(cellText=table_data[1:], colLabels=table_data[0],
                       cellLoc="center", loc="center", bbox=[0, 0, 1, 1])
tbl.auto_set_font_size(False)
tbl.set_fontsize(10)
for (r, c), cell in tbl.get_celld().items():
    if r == 0:
        cell.set_facecolor("#2C3E50")
        cell.set_text_props(color="white", fontweight="bold")
    else:
        cell.set_facecolor("#D4EDDA")
        cell.set_text_props(fontweight="bold")
axes[1, 1].set_title("Hypothesis Testing Summary", fontsize=13, fontweight="bold")

plt.suptitle("PLS-SEM Comprehensive Research Dashboard", fontsize=16, fontweight="bold", y=1.02)
plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig11_Summary_Dashboard.png"), dpi=800)
plt.close()

print("All plots generated successfully at 800 DPI with (11, 7) and Times New Roman 18pt bold!")

