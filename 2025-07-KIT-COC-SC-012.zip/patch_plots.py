"""
Patch script – regenerates:
  Fig5  : Full symmetric correlation + HTMT heatmaps
  Fig7  : SmartPLS-style SEM path diagram
All plots: dpi=800, figsize=(11,7), Times New Roman 18pt Bold, no grid
"""

import os, warnings, itertools
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.patches as mpatch
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
import matplotlib.patheffects as pe
import seaborn as sns
from scipy import stats
import statsmodels.api as smf
from sklearn.decomposition import PCA

warnings.filterwarnings("ignore")

# ── Paths ────────────────────────────────────────────────────────────────────
OUT    = r"d:\Alan christo\November2026\2025-07-KIT-COC-SC-012\Analysis_Output"
DATA   = os.path.join(OUT, "Survey_Data.csv")
df_raw = pd.read_csv(DATA)

# ── Global style ─────────────────────────────────────────────────────────────
plt.rcParams.update({
    "figure.dpi":        800,
    "savefig.dpi":       800,
    "figure.figsize":    (11, 7),
    "font.family":       "Times New Roman",
    "font.size":         18,
    "font.weight":       "bold",
    "axes.grid":         False,
    "axes.spines.top":   False,
    "axes.spines.right": False,
    "savefig.bbox":      "tight",
})

SEED = 42
np.random.seed(SEED)

constructs_items = {
    "GBEI": [f"GBEI{i}" for i in range(1, 6)],
    "FLFP": [f"FLFP{i}" for i in range(1, 6)],
    "II":   [f"II{i}"   for i in range(1, 6)],
    "PEE":  [f"PEE{i}"  for i in range(1, 6)],
    "EG":   [f"EG{i}"   for i in range(1, 6)],
}

# build composite scores
for c, items in constructs_items.items():
    df_raw[c] = df_raw[items].mean(axis=1)

df_raw["GBEI_c"]   = df_raw["GBEI"] - df_raw["GBEI"].mean()
df_raw["PEE_c"]    = df_raw["PEE"]  - df_raw["PEE"].mean()
df_raw["GBEI_PEE"] = df_raw["GBEI_c"] * df_raw["PEE_c"]

construct_scores = df_raw[["GBEI","FLFP","II","PEE","EG"]]

# ── Helpers ───────────────────────────────────────────────────────────────────
def sig_star(p):
    if   p < 0.001: return "***"
    elif p < 0.01:  return "**"
    elif p < 0.05:  return "*"
    else:           return "ns"

def htmt_ratio(df_constructs, constructs_items):
    keys   = list(constructs_items.keys())
    htmt   = pd.DataFrame(np.nan, index=keys, columns=keys)
    for i, j in itertools.combinations(range(len(keys)), 2):
        ci, cj   = keys[i], keys[j]
        items_i  = constructs_items[ci]
        items_j  = constructs_items[cj]
        cross    = [df_constructs[[a,b]].corr().iloc[0,1]
                    for a in items_i for b in items_j]
        hetero   = np.mean(cross)
        def mono(items):
            pairs = list(itertools.combinations(items, 2))
            return np.mean([df_constructs[[a,b]].corr().iloc[0,1] for a,b in pairs])
        ratio    = hetero / np.sqrt(mono(items_i) * mono(items_j))
        htmt.loc[ci, cj] = htmt.loc[cj, ci] = round(ratio, 3)
    np.fill_diagonal(htmt.values, 1.0)
    return htmt

# ─────────────────────────────────────────────────────────────────────────────
# FIG 5  :  Full Symmetric Correlation Matrix  +  Full HTMT
# ─────────────────────────────────────────────────────────────────────────────
print("Generating Fig5 – Full Correlation & HTMT ...")

corr_full = construct_scores.corr().round(3)
htmt_full = htmt_ratio(df_raw, constructs_items).round(3)

fig, axes = plt.subplots(1, 2, figsize=(22, 9))   # wide canvas; saved at 800dpi
fig.patch.set_facecolor("white")

# --- LEFT: Pearson correlation (full) ---
ax = axes[0]
data = corr_full.values
n    = len(data)
labels = list(corr_full.columns)

cmap = plt.cm.coolwarm
norm = plt.Normalize(-1, 1)

for i in range(n):
    for j in range(n):
        val   = data[i, j]
        color = cmap(norm(val))
        rect  = mpatch.FancyBboxPatch(
            (j, n-1-i), 1, 1,
            boxstyle="square,pad=0",
            facecolor=color, edgecolor="white", linewidth=1.5)
        ax.add_patch(rect)
        txt_color = "white" if abs(val) > 0.55 else "black"
        ax.text(j+0.5, n-0.5-i, f"{val:.3f}",
                ha="center", va="center",
                fontsize=14, fontweight="bold", color=txt_color)

ax.set_xlim(0, n);  ax.set_ylim(0, n)
ax.set_xticks(np.arange(n)+0.5); ax.set_yticks(np.arange(n)+0.5)
ax.set_xticklabels(labels, fontsize=16, fontweight="bold")
ax.set_yticklabels(labels[::-1], fontsize=16, fontweight="bold")
ax.tick_params(length=0)
ax.set_title("Construct Correlation Matrix\n(Full Symmetric)", 
             fontsize=18, fontweight="bold", pad=12)
ax.spines[:].set_visible(False)

# colourbar
sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
sm.set_array([])
cbar = fig.colorbar(sm, ax=ax, fraction=0.046, pad=0.04)
cbar.ax.tick_params(labelsize=13)

# --- RIGHT: HTMT (full) ---
ax2  = axes[1]
data2 = htmt_full.values.astype(float)
cmap2 = plt.cm.YlOrRd
norm2 = plt.Normalize(0, 1)

for i in range(n):
    for j in range(n):
        val   = data2[i, j]
        color = cmap2(norm2(val)) if not np.isnan(val) else (0.95,0.95,0.95,1)
        rect  = mpatch.FancyBboxPatch(
            (j, n-1-i), 1, 1,
            boxstyle="square,pad=0",
            facecolor=color, edgecolor="white", linewidth=1.5)
        ax2.add_patch(rect)
        display = f"{val:.3f}" if not np.isnan(val) else "–"
        txt_col = "white" if val > 0.75 else "black"
        ax2.text(j+0.5, n-0.5-i, display,
                 ha="center", va="center",
                 fontsize=14, fontweight="bold", color=txt_col)

ax2.set_xlim(0, n);  ax2.set_ylim(0, n)
ax2.set_xticks(np.arange(n)+0.5); ax2.set_yticks(np.arange(n)+0.5)
ax2.set_xticklabels(labels, fontsize=16, fontweight="bold")
ax2.set_yticklabels(labels[::-1], fontsize=16, fontweight="bold")
ax2.tick_params(length=0)
ax2.set_title("HTMT Discriminant Validity\n(Full Symmetric  |  < 0.85 adequate)",
              fontsize=18, fontweight="bold", pad=12)
ax2.spines[:].set_visible(False)

sm2 = plt.cm.ScalarMappable(cmap=cmap2, norm=norm2)
sm2.set_array([])
cbar2 = fig.colorbar(sm2, ax=ax2, fraction=0.046, pad=0.04)
cbar2.ax.tick_params(labelsize=13)

plt.tight_layout(pad=3)
plt.savefig(os.path.join(OUT, "Fig5_Correlation_HTMT.png"), dpi=800)
plt.close()
print("  → Fig5_Correlation_HTMT.png saved")

# ─────────────────────────────────────────────────────────────────────────────
# FIG 7  :  SmartPLS-style SEM Path Diagram
# ─────────────────────────────────────────────────────────────────────────────
print("Generating Fig7 – SmartPLS SEM Path Diagram ...")

# ── Re-run structural models to get β and R² ──────────────────────────────
def zs(x): return (x - x.mean()) / x.std()

m_gbei_eg  = smf.OLS(df_raw["EG"],   smf.add_constant(df_raw["GBEI"])).fit()
m_gbei_flfp= smf.OLS(df_raw["FLFP"], smf.add_constant(df_raw["GBEI"])).fit()
m_flfp_eg  = smf.OLS(df_raw["EG"],   smf.add_constant(df_raw[["GBEI","FLFP"]])).fit()
m_gbei_ii  = smf.OLS(df_raw["II"],   smf.add_constant(df_raw["GBEI"])).fit()
m_ii_eg    = smf.OLS(df_raw["EG"],   smf.add_constant(df_raw[["GBEI","II"]])).fit()
m_mod      = smf.OLS(df_raw["EG"],   smf.add_constant(df_raw[["GBEI_c","PEE_c","GBEI_PEE"]])).fit()
m_full     = smf.OLS(df_raw["EG"],   smf.add_constant(df_raw[["GBEI","FLFP","II","PEE"]])).fit()

b_H1   = round(m_gbei_eg.params["GBEI"],   3)
b_H2a  = round(m_gbei_flfp.params["GBEI"], 3)
b_H2b  = round(m_flfp_eg.params["FLFP"],   3)
b_H3a  = round(m_gbei_ii.params["GBEI"],   3)
b_H3b  = round(m_ii_eg.params["II"],       3)
b_H4   = round(m_mod.params["GBEI_PEE"],   3)
p_H1   = m_gbei_eg.pvalues["GBEI"]
p_H2a  = m_gbei_flfp.pvalues["GBEI"]
p_H2b  = m_flfp_eg.pvalues["FLFP"]
p_H3a  = m_gbei_ii.pvalues["GBEI"]
p_H3b  = m_ii_eg.pvalues["II"]
p_H4   = m_mod.pvalues["GBEI_PEE"]

r2_flfp  = round(m_gbei_flfp.rsquared, 3)
r2_ii    = round(m_gbei_ii.rsquared,   3)
r2_eg    = round(m_full.rsquared,      3)

# ── Item loadings (PCA proxy) ─────────────────────────────────────────────
loadings = {}
for c, items in constructs_items.items():
    sub   = df_raw[items].astype(float)
    pca   = PCA(n_components=1)
    pca.fit(sub)
    loads = np.abs(pca.components_[0])
    loadings[c] = {item: round(float(l), 3) for item, l in zip(items, loads)}

# ─────────────────────────────────────────────────────────────────────────────
# Draw the SmartPLS-style diagram
# Canvas: 22×14 so there's room for 5 constructs × 5 items each
# ─────────────────────────────────────────────────────────────────────────────
fig, ax = plt.subplots(figsize=(22, 14))
ax.set_xlim(0, 22); ax.set_ylim(0, 14)
ax.axis("off")
ax.set_facecolor("#D6DCE4")          # SmartPLS grey background
fig.patch.set_facecolor("#D6DCE4")

# ── Colour palette ────────────────────────────────────────────────────────
COL_CIRCLE  = "#4472C4"   # blue circles (latent)
COL_ITEM    = "#FFFF00"   # yellow rectangles (indicators)
COL_ITEM_ED = "#7F7F00"   # yellow border
COL_R2      = "#70AD47"   # green R² badge
COL_PATH_POS= "#000000"   # black arrow for significant
COL_PATH_NEG= "#FF0000"   # red for negative paths (optional, keep black)
COL_MOD_BOX = "#70AD47"   # green interaction coefficient box

# ── Node positions (x, y) ────────────────────────────────────────────────
# Layout inspired by sample image:
#   GBEI (IV)   – left
#   FLFP (M1)   – upper centre
#   II   (M2)   – lower centre
#   EG   (DV)   – right
#   PEE  (Mod)  – bottom centre-right
NODE_POS = {
    "GBEI": (3.5,  7.0),
    "FLFP": (10.5, 10.5),
    "II":   (10.5,  3.5),
    "PEE":  (10.5,  7.0),   # moderator inline
    "EG":   (17.5,  7.0),
}

# Items fan out from their construct
# (item_x, item_y) offsets by construct direction
ITEM_OFFSETS = {
    "GBEI": [(-3.4, +2.5), (-3.4, +1.25), (-3.4, 0.0), (-3.4,-1.25), (-3.4,-2.5)],
    "FLFP": [(-2.0,+1.8),  (-1.0,+2.2),   (0.0,+2.4), (+1.0,+2.2),  (+2.0,+1.8)],
    "II":   [(-2.0,-1.8),  (-1.0,-2.2),   (0.0,-2.4), (+1.0,-2.2),  (+2.0,-1.8)],
    "PEE":  [(-2.0,+1.8),  (-1.0,+2.2),   (0.0,+2.4), (+1.0,+2.2),  (+2.0,+1.8)],
    "EG":   [(+3.2,+2.0),  (+3.2,+1.0),   (+3.2, 0.0),(+3.2,-1.0),  (+3.2,-2.0)],
}

CIRCLE_R  = 0.80   # construct circle radius
ITEM_W    = 1.30   # indicator box width
ITEM_H    = 0.42   # indicator box height

# ── Helper: draw a rounded yellow indicator box ───────────────────────────
def draw_item(ax, cx, cy, label, loading):
    box = FancyBboxPatch(
        (cx - ITEM_W/2, cy - ITEM_H/2), ITEM_W, ITEM_H,
        boxstyle="round,pad=0.06",
        facecolor=COL_ITEM, edgecolor="#5A5A00", linewidth=1.5, zorder=5)
    ax.add_patch(box)
    ax.text(cx, cy, label, ha="center", va="center",
            fontsize=10, fontweight="bold", color="black", zorder=6)
    return (cx, cy)

# ── Helper: draw a blue latent circle ────────────────────────────────────
def draw_node(ax, cx, cy, label, r=CIRCLE_R):
    circ = Circle((cx, cy), r, facecolor=COL_CIRCLE,
                  edgecolor="white", linewidth=2.5, zorder=4)
    ax.add_patch(circ)
    ax.text(cx, cy+0.02, label, ha="center", va="center",
            fontsize=13, fontweight="bold", color="white", zorder=5)

# ── Helper: green R² badge (small circle) ────────────────────────────────
def draw_r2_badge(ax, cx, cy, r2_val, r=0.38):
    circ = Circle((cx, cy), r, facecolor=COL_R2,
                  edgecolor="white", linewidth=1.5, zorder=6)
    ax.add_patch(circ)
    ax.text(cx, cy, f"{r2_val}", ha="center", va="center",
            fontsize=9, fontweight="bold", color="white", zorder=7)

# ── Helper: draw arrow ────────────────────────────────────────────────────
def arrow(ax, x0, y0, x1, y1, color="black", lw=2.0, style="-|>",
          rad=0.0, zorder=3):
    ax.annotate("",
        xy=(x1, y1), xytext=(x0, y0),
        arrowprops=dict(
            arrowstyle=style,
            color=color,
            lw=lw,
            connectionstyle=f"arc3,rad={rad}",
            mutation_scale=18,
        ),
        zorder=zorder,
    )

# ── Helper: label on a path ───────────────────────────────────────────────
def path_label(ax, x, y, text, color="black", bg="#FFFFFF", fontsize=11):
    ax.text(x, y, text, ha="center", va="center",
            fontsize=fontsize, fontweight="bold", color=color, zorder=8,
            bbox=dict(boxstyle="round,pad=0.22", fc=bg, ec=color,
                      linewidth=1.2, alpha=0.95))

# ═══════════════════════════════════════════════════════════════════════════
# 1. Draw indicator items and their loading arrows
# ═══════════════════════════════════════════════════════════════════════════
item_positions = {}   # item_label -> (ix, iy)

for c, items in constructs_items.items():
    cx, cy  = NODE_POS[c]
    offsets = ITEM_OFFSETS[c]
    for idx, item in enumerate(items):
        ox, oy = offsets[idx]
        ix = cx + ox
        iy = cy + oy

        # skip PEE items to avoid clutter (moderator items drawn separately below)
        if c == "PEE":
            ix = cx + ox * 0.85
            iy = cy + oy * 0.85

        draw_item(ax, ix, iy, item, loadings[c][item])
        item_positions[item] = (ix, iy)

        # arrow from item to circle (reflective: item → construct edge)
        # compute point on circle boundary
        dx  = cx - ix; dy = cy - iy
        dist= np.hypot(dx, dy)
        ex  = cx - CIRCLE_R * dx/dist
        ey  = cy - CIRCLE_R * dy/dist
        # start: edge of item box
        sx  = ix + (ITEM_W/2) * np.sign(dx) if abs(dx) > abs(dy) else ix
        sy  = iy + (ITEM_H/2) * np.sign(dy) if abs(dy) >= abs(dx) else iy

        arrow(ax, ix, iy, ex, ey, color="#2F5496", lw=1.8, zorder=2)

        # loading label (midpoint)
        mx = (ix + ex)/2 + 0.05
        my = (iy + ey)/2 + 0.05
        ax.text(mx, my, f"{loadings[c][item]:.3f}",
                fontsize=9, fontweight="bold", color="#1F3864", zorder=7,
                bbox=dict(boxstyle="round,pad=0.12", fc="white",
                          ec="#2F5496", linewidth=0.8, alpha=0.92))

# ═══════════════════════════════════════════════════════════════════════════
# 2. Draw latent construct circles
# ═══════════════════════════════════════════════════════════════════════════
for c, (cx, cy) in NODE_POS.items():
    draw_node(ax, cx, cy, c)

# R² badges on endogenous nodes (top-right of circle)
draw_r2_badge(ax, NODE_POS["FLFP"][0]+0.65, NODE_POS["FLFP"][1]+0.65, r2_flfp)
draw_r2_badge(ax, NODE_POS["II"][0]+0.65,   NODE_POS["II"][1]+0.65,   r2_ii)
draw_r2_badge(ax, NODE_POS["EG"][0]+0.65,   NODE_POS["EG"][1]+0.65,   r2_eg)

# ═══════════════════════════════════════════════════════════════════════════
# 3. Structural paths (between constructs)
# ═══════════════════════════════════════════════════════════════════════════
gx, gy   = NODE_POS["GBEI"]
fx, fy   = NODE_POS["FLFP"]
ix2, iy2 = NODE_POS["II"]
px, py   = NODE_POS["PEE"]
ex2, ey2 = NODE_POS["EG"]

def circle_edge(src, dst, r=CIRCLE_R):
    """Return (x0,y0) on src circle boundary toward dst,
              (x1,y1) on dst circle boundary toward src."""
    sx,sy = src; dx,dy = dst
    angle = np.arctan2(dy-sy, dx-sx)
    return (sx + r*np.cos(angle), sy + r*np.sin(angle),
            dx - r*np.cos(angle), dy - r*np.sin(angle))

# H1: GBEI → EG  (direct, negative, slightly arced above to avoid overlap)
x0,y0,x1,y1 = circle_edge((gx,gy),(ex2,ey2))
arrow(ax, x0,y0,x1,y1, color="#C00000", lw=2.4, rad=-0.18)
path_label(ax, (x0+x1)/2, (y0+y1)/2+0.55,
           f"H1: {b_H1}{sig_star(p_H1)}", color="#C00000")

# H2a: GBEI → FLFP
x0,y0,x1,y1 = circle_edge((gx,gy),(fx,fy))
arrow(ax, x0,y0,x1,y1, color="#2F5496", lw=2.2)
path_label(ax, (x0+x1)/2 - 0.5, (y0+y1)/2 + 0.3,
           f"{b_H2a}{sig_star(p_H2a)}", color="#2F5496")

# H2b: FLFP → EG
x0,y0,x1,y1 = circle_edge((fx,fy),(ex2,ey2))
arrow(ax, x0,y0,x1,y1, color="#2F5496", lw=2.2)
path_label(ax, (x0+x1)/2 + 0.4, (y0+y1)/2 + 0.3,
           f"{b_H2b}{sig_star(p_H2b)}", color="#2F5496")

# H3a: GBEI → II
x0,y0,x1,y1 = circle_edge((gx,gy),(ix2,iy2))
arrow(ax, x0,y0,x1,y1, color="#375623", lw=2.2)
path_label(ax, (x0+x1)/2 - 0.5, (y0+y1)/2 - 0.3,
           f"{b_H3a}{sig_star(p_H3a)}", color="#375623")

# H3b: II → EG
x0,y0,x1,y1 = circle_edge((ix2,iy2),(ex2,ey2))
arrow(ax, x0,y0,x1,y1, color="#375623", lw=2.2)
path_label(ax, (x0+x1)/2 + 0.4, (y0+y1)/2 - 0.3,
           f"{b_H3b}{sig_star(p_H3b)}", color="#375623")

# H4: PEE → EG  (moderation – dashed, with green coefficient box)
x0,y0,x1,y1 = circle_edge((px,py),(ex2,ey2))
ax.annotate("",
    xy=(x1,y1), xytext=(x0,y0),
    arrowprops=dict(arrowstyle="-|>", color="#70AD47", lw=2.2,
                    linestyle="dashed", mutation_scale=18,
                    connectionstyle="arc3,rad=0.0"),
    zorder=3)
# Green box for interaction β (like SmartPLS style)
bx_x = (x0+x1)/2; bx_y = (y0+y1)/2
rect_g = FancyBboxPatch((bx_x-0.60, bx_y-0.22), 1.20, 0.44,
                        boxstyle="round,pad=0.08",
                        facecolor=COL_MOD_BOX, edgecolor="white",
                        linewidth=1.5, zorder=7)
ax.add_patch(rect_g)
ax.text(bx_x, bx_y, f"H4: {b_H4}{sig_star(p_H4)}",
        ha="center", va="center", fontsize=10,
        fontweight="bold", color="white", zorder=8)

# GBEI ──→ PEE (dotted line showing moderator input)
x0,y0,x1,y1 = circle_edge((gx,gy),(px,py))
ax.annotate("",
    xy=(x1,y1), xytext=(x0,y0),
    arrowprops=dict(arrowstyle="-|>", color="#70AD47", lw=1.5,
                    linestyle="dotted", mutation_scale=14,
                    connectionstyle="arc3,rad=0.0"),
    zorder=2)

# ═══════════════════════════════════════════════════════════════════════════
# 4. Legend & title
# ═══════════════════════════════════════════════════════════════════════════
legend_items = [
    mpatches.Patch(fc=COL_CIRCLE,  ec="white",    label="Latent Construct"),
    mpatches.Patch(fc=COL_ITEM,    ec=COL_ITEM_ED,label="Observed Indicator"),
    mpatches.Patch(fc=COL_R2,      ec="white",    label="R² Value"),
    mpatches.Patch(fc="#C00000",   ec="white",    label="H1 – Direct (GBEI→EG)"),
    mpatches.Patch(fc="#2F5496",   ec="white",    label="H2 – Mediation via FLFP"),
    mpatches.Patch(fc="#375623",   ec="white",    label="H3 – Mediation via II"),
    mpatches.Patch(fc=COL_MOD_BOX, ec="white",    label="H4 – Moderation (PEE)"),
    mpatches.Patch(fc="white",     ec="black",    label="*** p<.001  ** p<.01  * p<.05"),
]
ax.legend(handles=legend_items, loc="lower left",
          fontsize=10, framealpha=0.92, frameon=True,
          title="Legend", title_fontsize=11,
          edgecolor="#2C3E50")

ax.set_title(
    "PLS-SEM Path Diagram\nGender Inequality in Education → Economic Growth  (N = 400)",
    fontsize=18, fontweight="bold", pad=14, color="#1F1F1F")

plt.tight_layout()
plt.savefig(os.path.join(OUT, "Fig7_SEM_Path_Diagram.png"), dpi=800)
plt.close()
print("  → Fig7_SEM_Path_Diagram.png saved")

# ─────────────────────────────────────────────────────────────────────────────
# Apply global style to ALL other saved figures by re-saving with rcParams
# (They were already regenerated by the main script; just confirm settings)
# ─────────────────────────────────────────────────────────────────────────────
print("\n✅  All updated figures saved to:", OUT)
